﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment
{
    public partial class FrmTProfile : Form
    {
        public static string name;
        public FrmTProfile(string n)
        {
            name= n;
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            FrmTutorHome frm= new FrmTutorHome(name);
            frm.ShowDialog();
            
        }
    }
}
