﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace IOOP_Assignment
{
    public partial class Income : Form
    {
        private string name;
        public Income(string n)
        {
            InitializeComponent();
            name = n;
        }

        private void Income_Load(object sender,EventArgs e)
        {
            
        }

        private void Income_load(object sender,EventArgs e)
        {
           
        }

        private void cmbMonth_SelectedIndexChanged(object sender, EventArgs e)
        {
            lstIncome.Items.Clear();
            int total=0;
            string month = cmbMonth.Text;
            
            Admin a =new Admin();
            ArrayList incomeInfo= new ArrayList();
            incomeInfo = a.viewIncome(month);
            foreach( var i in incomeInfo)
            {
                lstIncome.Items.Add(i);
            }
            ArrayList income = new ArrayList();
            income = a.viewTotal(month);
            foreach( var i in income) 
            {
                string  n = i.ToString();
                int num= int.Parse(n);
                total += num;
            }
            lblTotal.Text = "Total income: RM" + total;
        }

        private void Income_Load_1(object sender, EventArgs e)
        {

        }
    }
}
