﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment
{
    public partial class Update : Form
    {
        public static string adminName;
        public Update()
        {
            InitializeComponent();
        }

        public Update(string n)
        {
            InitializeComponent();
            adminName = n;
        }

        /*
        private void Update_Load(object sender, EventArgs e)
        {
            Admin obj1 = new Admin(adminName);
            Admin.viewProfile(obj1);
            
            txtEmail.Text = obj1.Email;
            txtContact.Text = obj1.ContactNum;
            txtAddress.Text = obj1.Address;
        }*/

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Admin obj1 = new Admin(adminName);
            MessageBox.Show(obj1.updateProfile(txtEmail.Text, txtContact.Text, txtAddress.Text));
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
