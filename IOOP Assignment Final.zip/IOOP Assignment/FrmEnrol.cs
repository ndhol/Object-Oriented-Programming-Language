﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace IOOP_Assignment
{
    public partial class FrmEnrol : Form
    {
        public static string tutor;
        public static string un;
        public FrmEnrol(string n)
        {
            InitializeComponent();
            tutor = n;
            un = n;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            FrmTutorHome frm= new FrmTutorHome(un);
            frm.ShowDialog();
        }

        private void FrmEnrol_Load(object sender, EventArgs e)
        {
            MessageBox.Show(tutor);
            ArrayList level= new ArrayList();
            level = Class.viewLevel(tutor);
            foreach(var item in level)
            {
                comboBox1.Items.Add(item);
            }
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            lbEnrol.Items.Clear();
            
            string l = comboBox1.Text;
            ArrayList name = new ArrayList();
            name = Class.viewStudent(tutor, l);
            foreach (var item in name)
            {
                lbEnrol.Items.Add(item);
            }
        }
    }
}
