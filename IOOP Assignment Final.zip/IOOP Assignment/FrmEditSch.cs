﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment
{
    public partial class FrmEditSch : Form
    {
        string name;
        
        string level;
        string charge;
        string sub;
        public FrmEditSch(string n,string l,string c,string s)
        {
            InitializeComponent();
            name = n;
            level = l;
            charge = c;
            sub = s;
        }

       

   

        private void FrmEditSch_Load(object sender, EventArgs e)
        {
            ArrayList dayTime = new ArrayList();
            dayTime = Class.allDayTime();
            foreach (var item in dayTime)
            {
                listBox1.Items.Add(item);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string day=cmbAddDay.Text;
            string time=cmbAddTime.Text;
            Class addition = new Class(name, level, sub, day, time);
            string status=addition.addTime(name, level, sub, day, time);
            MessageBox.Show(status);
          
        }
    }
}
