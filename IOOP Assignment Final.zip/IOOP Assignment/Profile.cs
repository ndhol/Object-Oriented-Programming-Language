﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment
{
    public partial class Profile : Form
    {
        private string name;
       
        public Profile(string n,string r)
        {
            InitializeComponent();
            name = n;
            
        }
       /* public Profile(string n, string em, string p)
        {
            InitializeComponent();
            
        }

       /* public string Name1 { get => Name; set => Name = value; }
        public string Email1 { get => Email; set => Email = value; }
        public string PhoneNum1 { get => PhoneNum; set => PhoneNum = value; }*/

        private void label5_Click(object sender, EventArgs e)
        {
            
        }

        private void Profile_Load(object sender, EventArgs e)
        {
            User obj1 = new User(name);
            User.viewProfile(obj1);
            lblName.Text = name;
            lblEmail.Text = obj1.Email;
            lblPhone.Text = obj1.PhoneNum;
            
        }
    }
}
