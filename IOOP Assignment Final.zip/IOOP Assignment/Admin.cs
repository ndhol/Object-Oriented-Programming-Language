﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IOOP_Assignment
{
    internal class Admin
    {
        private string adminName;
        private string tutorRole = "tutor";
        private string recepRole = "receptionist";
       
        private string name;
        private string icNum;
        private string address;
        private string contactNum;
        private string email;
        private string subject;
        private string level;
        private string month;
        private ArrayList IncomeLev;
        private ArrayList IncomeMonth;
        private ArrayList income;

        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

        public string Name { get => name; set => name = value; }
        public string Email { get => email; set => email = value; }
        public string ContactNum { get => contactNum; set => contactNum = value; }
        public string Address { get=> address; set => address = value; }
        
        public ArrayList Month1 { get => IncomeMonth; set => IncomeMonth = value; }
        public ArrayList IncomeLev1 { get => IncomeLev; set => IncomeLev = value; }
        public ArrayList Income { get => income; set => income = value; }

        public Admin(string n, string i,string a, string num,string e)
        {
            name = n;
            icNum = i;
            address=a;
            contactNum = num;
            email = e;
        }

        
        public Admin(string n,string s, string l)
        {
            name = n;
            subject = s;
            level = l;
        }
        public Admin(string n)
        {
            name = n;
        }

        public Admin()
        {

        }
        public string addTutor()
        {

            string status;
            con.Open();
            SqlCommand cmd8 = new SqlCommand("select count (*)  from staff where name= '" + name + "'", con);
            int count = Convert.ToInt32(cmd8.ExecuteScalar().ToString());
            if (count > 0)
            {
                status = "Tutor already registered";
                con.Close();
                return status;
            }
            SqlCommand cmd = new SqlCommand("insert into staff(name,icNum,address,contactNum,email,role)values(@name,@ic,@add,@contact,@em,@role)", con);

            SqlCommand cmd2 = new SqlCommand("insert into users (username,password,role) values(@name,'123','tutor')", con);
            cmd.Parameters.AddWithValue("@name", name);
            cmd2.Parameters.AddWithValue("@name", name);
            cmd.Parameters.AddWithValue("@ic", icNum);
            cmd.Parameters.AddWithValue("@add", address);
            cmd.Parameters.AddWithValue("@em", email);
            cmd.Parameters.AddWithValue("@contact", contactNum);
            cmd.Parameters.AddWithValue("@role", tutorRole);
            cmd2.ExecuteNonQuery();
            int i = cmd.ExecuteNonQuery();
            if (i != 0)
                status = "Registration Successful.";
            else
                status = "Unable to register.";
            con.Close();
            return status;
        }

        public string assignTutor()
        {
            string status;
            con.Open();
            

            SqlCommand cmd= new SqlCommand("insert into subject(tutor,subject,level,charge)values(@name,@subject,@level,'0')", con);
            cmd.Parameters.AddWithValue("@name", name);
            cmd.Parameters.AddWithValue("@subject", subject);
            cmd.Parameters.AddWithValue("@level", level);

            int i = cmd.ExecuteNonQuery();
            if (i != 0)
                status = "Assign Successful.";
            else
                status = "Unable to assign.";
            con.Close();
            return status;

        }
        //delTutor
        public static ArrayList viewAlltutor()//delRecep
        {
            //arraylist to create dynamic array
            ArrayList nm = new ArrayList();
            con.Open();

            SqlCommand cmd = new SqlCommand("select name from staff where role='tutor'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                nm.Add(rd.GetString(0));//add element into arraylist
            }
            con.Close();
            return nm;
        }
        public string deleteTutor()
        {
            string status;
            con.Open();
            SqlCommand cmd = new SqlCommand("Delete from staff where name=@name and role='tutor'", con);
            SqlCommand cmd1 = new SqlCommand("Delete from classInfo where tutor=@name", con);
            SqlCommand cmd2= new SqlCommand("Update enrolement set tutor='unassigned' where tutor=@name", con);
            SqlCommand cmd3 = new SqlCommand("Delete from users where username=@name", con);

            cmd.Parameters.AddWithValue("@name", name);
            cmd1.Parameters.AddWithValue("@name", name);
            cmd2.Parameters.AddWithValue("@name", name);
            cmd3.Parameters.AddWithValue("@name", name);

            int i = cmd.ExecuteNonQuery();
            int j = cmd1.ExecuteNonQuery();
            if (i != 0)
            {
                status = "Delete successfully.";
            }
            else
            {
                status = "Unable to delete.";
            }
            con.Close();
            
            
            if (j != 0)
            {
                status = "Delete successfully.";
            }
            else
            {
                status = "Unable to delete.";
            }
            con.Close();
            return status;
        }

       

        
        public string addRecep()
        {
            string status;
            con.Open();
            SqlCommand cmd8 = new SqlCommand("select count (*)  from staff where name= '" + name + "'", con);
            int count = Convert.ToInt32(cmd8.ExecuteScalar().ToString());
            if (count > 0)
            {
                status = "Receptionist already registered";
                con.Close();
                return status;
            }
            SqlCommand cmd = new SqlCommand("insert into staff(name,icNum,address,contactNum,email,role)values(@name,@ic,@add,@contact,@em,@role)", con);

            SqlCommand cmd2 = new SqlCommand("insert into users (username,password,role) values(@name,'345','receptionist')", con);
            cmd.Parameters.AddWithValue("@name", name);
            cmd2.Parameters.AddWithValue("@name", name);
            cmd.Parameters.AddWithValue("@ic", icNum);
            cmd.Parameters.AddWithValue("@add", Address);
            cmd.Parameters.AddWithValue("@em", email);
            cmd.Parameters.AddWithValue("@contact", contactNum);
            cmd.Parameters.AddWithValue("@role", recepRole);
            cmd2.ExecuteNonQuery();
            
            int i = cmd.ExecuteNonQuery();
            if (i != 0)
                status = "Registration Successful.";
            else
                status = "Unable to register.";
            con.Close();
            return status;
        } 
        
        public static ArrayList viewAllrecep()//delRecep
        {
            //arraylist to create dynamic array
            ArrayList nm = new ArrayList();
            con.Open();

            SqlCommand cmd = new SqlCommand("select name from staff where role='receptionist'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                nm.Add(rd.GetString(0));//add element into arraylist
            }
            con.Close();
            return nm;
        }

        public string deleteReceptionist()
        {
            string status;
            con.Open();
            SqlCommand cmd = new SqlCommand("Delete from staff where name=@name", con);
            cmd.Parameters.AddWithValue("@name", name);
            int i = cmd.ExecuteNonQuery();
            if(i!=0)
            {
                status = "Delete successfully.";
            }
            else
            {
                status = "Unable to delete.";
            }
            con.Close();
            return status;
        }

        public static void viewProfile(Admin o1)//Update admin profile
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from admins where adminName='" + o1.adminName + "'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read()) 
            {
                o1.Email= rd.GetString(0);
                o1.ContactNum= rd.GetString(1);
                o1.Address= rd.GetString(2);
            }
            con.Close();
        }

        public string updateProfile(string em, string num,string add)//Update
        {
            string status;
            con.Open();

            email = em;
            contactNum = num;
            address = add;

            SqlCommand cmd = new SqlCommand("Update Admins set email ='" + email + "',ContactNumbers='" + contactNum + "'where AdminName = '" + adminName + "'", con);
            int i = cmd.ExecuteNonQuery();
            if (i != 0)
                status = "Update Successfully.";
            else
                status = "Unable to update.";
            con.Close();

            return status;

        }
        
        public ArrayList viewIncome(string m)
        {
            //arraylist to create dynamic array
            string month = m;
            ArrayList lv = new ArrayList();
            con.Open();
            SqlCommand cmd = new SqlCommand("select level,subject,payment from enrolement where status= 'paid' and month=@m order by level,subject", con);
            cmd.Parameters.AddWithValue("@m", month);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                lv.Add(rd.GetString(0) + "\t\t" + rd.GetString(1) + "\t\t" +"\t\tRM"+rd.GetString(2));//add element into arraylist
            }
            con.Close();
            return lv;
        }

        public  ArrayList viewTotal(string m)
        {
            //arraylist to create dynamic array
            ArrayList nm = new ArrayList();
            con.Open();
            string month = m;
            SqlCommand cmd = new SqlCommand("select payment from enrolement where status= 'paid' and month=@m", con);
            cmd.Parameters.AddWithValue("@m", month);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                nm.Add(rd.GetString(0));//add element into arraylist
          
            }
            con.Close();
            return nm;
        }

       
    }
}
