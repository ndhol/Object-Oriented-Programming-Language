﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace IOOP_Assignment
{
    public partial class DeleteStudent : Form
    {
        public DeleteStudent()
        {
            InitializeComponent();
        }

        private void DeleteStudent_Load(object sender, EventArgs e)
        {
            cmbStudent.Items.Clear();
            ArrayList names = new ArrayList();
            Receptionist students = new Receptionist();
            names = students.viewStudent();
            foreach (var i in names)
            {
                cmbStudent.Items.Add(i);

            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            string name=cmbStudent.Text;
            Receptionist delete = new Receptionist(name);
            string status = delete.deleteStudent();
            MessageBox.Show(status);
            DeleteStudent_Load(sender, e);
        }

        private void cmbStudent_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
