﻿namespace IOOP_Assignment
{
    partial class FormRegisterTutor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblRegisterTutor = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblIC = new System.Windows.Forms.Label();
            this.lblAddress = new System.Windows.Forms.Label();
            this.lblContact = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtIC = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtContact = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.btnRegisterTutor = new System.Windows.Forms.Button();
            this.btnAssignTutor = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblRegisterTutor
            // 
            this.lblRegisterTutor.AutoSize = true;
            this.lblRegisterTutor.BackColor = System.Drawing.Color.IndianRed;
            this.lblRegisterTutor.Font = new System.Drawing.Font("Rockwell", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRegisterTutor.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblRegisterTutor.Location = new System.Drawing.Point(442, 70);
            this.lblRegisterTutor.Name = "lblRegisterTutor";
            this.lblRegisterTutor.Size = new System.Drawing.Size(367, 59);
            this.lblRegisterTutor.TabIndex = 0;
            this.lblRegisterTutor.Text = "Register Tutor";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblName.Location = new System.Drawing.Point(76, 222);
            this.lblName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(168, 33);
            this.lblName.TabIndex = 1;
            this.lblName.Text = "Tutor Name : ";
            // 
            // lblIC
            // 
            this.lblIC.AutoSize = true;
            this.lblIC.Location = new System.Drawing.Point(76, 311);
            this.lblIC.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblIC.Name = "lblIC";
            this.lblIC.Size = new System.Drawing.Size(160, 33);
            this.lblIC.TabIndex = 3;
            this.lblIC.Text = "IC Number : ";
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new System.Drawing.Point(76, 398);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(127, 33);
            this.lblAddress.TabIndex = 4;
            this.lblAddress.Text = "Address : ";
            // 
            // lblContact
            // 
            this.lblContact.AutoSize = true;
            this.lblContact.Location = new System.Drawing.Point(645, 222);
            this.lblContact.Name = "lblContact";
            this.lblContact.Size = new System.Drawing.Size(220, 33);
            this.lblContact.TabIndex = 5;
            this.lblContact.Text = "Contact Number : ";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(645, 324);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(197, 33);
            this.lblEmail.TabIndex = 6;
            this.lblEmail.Text = "Email Address : ";
            // 
            // txtName
            // 
            this.txtName.ForeColor = System.Drawing.Color.Silver;
            this.txtName.Location = new System.Drawing.Point(249, 222);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(221, 39);
            this.txtName.TabIndex = 7;
            this.txtName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtIC
            // 
            this.txtIC.Location = new System.Drawing.Point(249, 305);
            this.txtIC.Name = "txtIC";
            this.txtIC.Size = new System.Drawing.Size(168, 39);
            this.txtIC.TabIndex = 9;
            // 
            // txtAddress
            // 
            this.txtAddress.ForeColor = System.Drawing.Color.Silver;
            this.txtAddress.Location = new System.Drawing.Point(249, 398);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(418, 39);
            this.txtAddress.TabIndex = 10;
            this.txtAddress.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtContact
            // 
            this.txtContact.Location = new System.Drawing.Point(891, 222);
            this.txtContact.Name = "txtContact";
            this.txtContact.Size = new System.Drawing.Size(267, 39);
            this.txtContact.TabIndex = 11;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(891, 321);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(267, 39);
            this.txtEmail.TabIndex = 12;
            // 
            // btnRegisterTutor
            // 
            this.btnRegisterTutor.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnRegisterTutor.Location = new System.Drawing.Point(752, 582);
            this.btnRegisterTutor.Name = "btnRegisterTutor";
            this.btnRegisterTutor.Size = new System.Drawing.Size(166, 46);
            this.btnRegisterTutor.TabIndex = 13;
            this.btnRegisterTutor.Text = "Register";
            this.btnRegisterTutor.UseVisualStyleBackColor = true;
            this.btnRegisterTutor.Click += new System.EventHandler(this.btnRegisterTutor_Click);
            // 
            // btnAssignTutor
            // 
            this.btnAssignTutor.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnAssignTutor.Location = new System.Drawing.Point(1019, 582);
            this.btnAssignTutor.Name = "btnAssignTutor";
            this.btnAssignTutor.Size = new System.Drawing.Size(169, 46);
            this.btnAssignTutor.TabIndex = 14;
            this.btnAssignTutor.Text = "Assign Tutor";
            this.btnAssignTutor.UseVisualStyleBackColor = true;
            this.btnAssignTutor.Click += new System.EventHandler(this.btnAssignTutor_Click);
            // 
            // FormRegisterTutor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightCoral;
            this.ClientSize = new System.Drawing.Size(1274, 829);
            this.Controls.Add(this.btnAssignTutor);
            this.Controls.Add(this.btnRegisterTutor);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.txtContact);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.txtIC);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.lblContact);
            this.Controls.Add(this.lblAddress);
            this.Controls.Add(this.lblIC);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblRegisterTutor);
            this.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Name = "FormRegisterTutor";
            this.Text = "FormRegisterTutor";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblRegisterTutor;
        private Label lblName;
        private Label lblIC;
        private Label lblAddress;
        private Label lblContact;
        private Label lblEmail;
        private TextBox txtName;
        private TextBox txtIC;
        private TextBox txtAddress;
        private TextBox txtContact;
        private TextBox txtEmail;
        private Button btnRegisterTutor;
        private Button btnAssignTutor;
    }
}