﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace IOOP_Assignment
{
    public partial class FormDelRecep : Form
    {
        public FormDelRecep()
        {
            InitializeComponent();
        }

        private void FormDelRecep_Load(object sender, EventArgs e)
        {
            
        }

        private void btnDelRecep_Click(object sender, EventArgs e)
        {
            Admin obj1 = new Admin(lstRecepName.Text);
            MessageBox.Show(obj1.deleteReceptionist());
            FormDelRecep_Load_1(sender, e);
        }

        private void FormDelRecep_Load_1(object sender, EventArgs e)
        {
            lstRecepName.Items.Clear();
            ArrayList name = new ArrayList();
            name = Admin.viewAllrecep();
            foreach (var item in name)
            {
                lstRecepName.Items.Add(item);
            }
        }
    }
}
