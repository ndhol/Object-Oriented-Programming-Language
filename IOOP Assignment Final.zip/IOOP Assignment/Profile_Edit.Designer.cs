﻿namespace IOOP_Assignment
{
    partial class frm_ProfileEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pic_ProfilePic = new System.Windows.Forms.PictureBox();
            this.lbl_Name = new System.Windows.Forms.Label();
            this.txtbox_Name = new System.Windows.Forms.TextBox();
            this.txtBox_Email = new System.Windows.Forms.TextBox();
            this.lbl_Email = new System.Windows.Forms.Label();
            this.lbl_ContactNum = new System.Windows.Forms.Label();
            this.txtBox_ContactNum = new System.Windows.Forms.TextBox();
            this.txtBox_Address = new System.Windows.Forms.TextBox();
            this.lbl_Address = new System.Windows.Forms.Label();
            this.txtBox_Month = new System.Windows.Forms.TextBox();
            this.lbl_Month = new System.Windows.Forms.Label();
            this.btn_Update = new System.Windows.Forms.Button();
            this.btn_Return = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pic_ProfilePic)).BeginInit();
            this.SuspendLayout();
            // 
            // pic_ProfilePic
            // 
            this.pic_ProfilePic.Location = new System.Drawing.Point(199, 32);
            this.pic_ProfilePic.Name = "pic_ProfilePic";
            this.pic_ProfilePic.Size = new System.Drawing.Size(202, 225);
            this.pic_ProfilePic.TabIndex = 0;
            this.pic_ProfilePic.TabStop = false;
            this.pic_ProfilePic.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // lbl_Name
            // 
            this.lbl_Name.AutoSize = true;
            this.lbl_Name.Location = new System.Drawing.Point(195, 284);
            this.lbl_Name.Name = "lbl_Name";
            this.lbl_Name.Size = new System.Drawing.Size(56, 20);
            this.lbl_Name.TabIndex = 1;
            this.lbl_Name.Text = "Name: ";
            // 
            // txtbox_Name
            // 
            this.txtbox_Name.Location = new System.Drawing.Point(258, 280);
            this.txtbox_Name.Name = "txtbox_Name";
            this.txtbox_Name.Size = new System.Drawing.Size(125, 27);
            this.txtbox_Name.TabIndex = 2;
            // 
            // txtBox_Email
            // 
            this.txtBox_Email.Location = new System.Drawing.Point(258, 319);
            this.txtBox_Email.Name = "txtBox_Email";
            this.txtBox_Email.Size = new System.Drawing.Size(125, 27);
            this.txtBox_Email.TabIndex = 6;
            this.txtBox_Email.TabStop = false;
            // 
            // lbl_Email
            // 
            this.lbl_Email.AutoSize = true;
            this.lbl_Email.Location = new System.Drawing.Point(199, 319);
            this.lbl_Email.Name = "lbl_Email";
            this.lbl_Email.Size = new System.Drawing.Size(53, 20);
            this.lbl_Email.TabIndex = 5;
            this.lbl_Email.Text = "Email: ";
            // 
            // lbl_ContactNum
            // 
            this.lbl_ContactNum.AutoSize = true;
            this.lbl_ContactNum.Location = new System.Drawing.Point(130, 359);
            this.lbl_ContactNum.Name = "lbl_ContactNum";
            this.lbl_ContactNum.Size = new System.Drawing.Size(125, 20);
            this.lbl_ContactNum.TabIndex = 7;
            this.lbl_ContactNum.Text = "Contact Number: ";
            // 
            // txtBox_ContactNum
            // 
            this.txtBox_ContactNum.Location = new System.Drawing.Point(258, 359);
            this.txtBox_ContactNum.Name = "txtBox_ContactNum";
            this.txtBox_ContactNum.Size = new System.Drawing.Size(125, 27);
            this.txtBox_ContactNum.TabIndex = 8;
            this.txtBox_ContactNum.TabStop = false;
            // 
            // txtBox_Address
            // 
            this.txtBox_Address.Location = new System.Drawing.Point(258, 399);
            this.txtBox_Address.Name = "txtBox_Address";
            this.txtBox_Address.Size = new System.Drawing.Size(125, 27);
            this.txtBox_Address.TabIndex = 10;
            this.txtBox_Address.TabStop = false;
            // 
            // lbl_Address
            // 
            this.lbl_Address.AutoSize = true;
            this.lbl_Address.Location = new System.Drawing.Point(184, 399);
            this.lbl_Address.Name = "lbl_Address";
            this.lbl_Address.Size = new System.Drawing.Size(69, 20);
            this.lbl_Address.TabIndex = 9;
            this.lbl_Address.Text = "Address: ";
            this.lbl_Address.Click += new System.EventHandler(this.label4_Click);
            // 
            // txtBox_Month
            // 
            this.txtBox_Month.Location = new System.Drawing.Point(258, 439);
            this.txtBox_Month.Name = "txtBox_Month";
            this.txtBox_Month.Size = new System.Drawing.Size(125, 27);
            this.txtBox_Month.TabIndex = 12;
            this.txtBox_Month.TabStop = false;
            // 
            // lbl_Month
            // 
            this.lbl_Month.AutoSize = true;
            this.lbl_Month.Location = new System.Drawing.Point(194, 439);
            this.lbl_Month.Name = "lbl_Month";
            this.lbl_Month.Size = new System.Drawing.Size(55, 20);
            this.lbl_Month.TabIndex = 11;
            this.lbl_Month.Text = "Month:";
            // 
            // btn_Update
            // 
            this.btn_Update.Location = new System.Drawing.Point(258, 493);
            this.btn_Update.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Update.Name = "btn_Update";
            this.btn_Update.Size = new System.Drawing.Size(86, 31);
            this.btn_Update.TabIndex = 13;
            this.btn_Update.Text = "Update";
            this.btn_Update.UseVisualStyleBackColor = true;
            this.btn_Update.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_Return
            // 
            this.btn_Return.Location = new System.Drawing.Point(527, 527);
            this.btn_Return.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Return.Name = "btn_Return";
            this.btn_Return.Size = new System.Drawing.Size(86, 31);
            this.btn_Return.TabIndex = 14;
            this.btn_Return.Text = "Return";
            this.btn_Return.UseVisualStyleBackColor = true;
            this.btn_Return.Click += new System.EventHandler(this.btn_Return_Click);
            // 
            // frm_ProfileEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(626, 573);
            this.Controls.Add(this.btn_Return);
            this.Controls.Add(this.btn_Update);
            this.Controls.Add(this.txtBox_Month);
            this.Controls.Add(this.lbl_Month);
            this.Controls.Add(this.txtBox_Address);
            this.Controls.Add(this.lbl_Address);
            this.Controls.Add(this.txtBox_ContactNum);
            this.Controls.Add(this.lbl_ContactNum);
            this.Controls.Add(this.txtBox_Email);
            this.Controls.Add(this.lbl_Email);
            this.Controls.Add(this.txtbox_Name);
            this.Controls.Add(this.lbl_Name);
            this.Controls.Add(this.pic_ProfilePic);
            this.Name = "frm_ProfileEdit";
            this.Text = "Profile Edit";
            this.Load += new System.EventHandler(this.frm_ProfileEdit_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pic_ProfilePic)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox pic_ProfilePic;
        private Label lbl_Name;
        private TextBox txtbox_Name;
        private TextBox txtBox_Email;
        private Label lbl_Email;
        private Label lbl_ContactNum;
        private TextBox txtBox_ContactNum;
        private TextBox txtBox_Address;
        private Label lbl_Address;
        private TextBox txtBox_Month;
        private Label lbl_Month;
        private Button btn_Update;
        private Button btn_Return;
    }
}