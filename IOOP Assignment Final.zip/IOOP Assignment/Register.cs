﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace IOOP_Assignment
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnProceed_Click(object sender, EventArgs e)
        {
            string name=txtName.Text;
            Receptionist obj1 = new Receptionist(name, txtIC.Text,txtEmail.Text, txtPhone.Text, txtAddress.Text, cmblevel.Text, cmbEnroll.Text);
            MessageBox.Show(obj1.addStudent());
            Subject frm = new Subject(name);
            frm.Show();
        }
    }
}
