﻿namespace IOOP_Assignment
{
    partial class FormAssign
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAssign = new System.Windows.Forms.Label();
            this.lblAssignName = new System.Windows.Forms.Label();
            this.lblAssignNum = new System.Windows.Forms.Label();
            this.lblSubject = new System.Windows.Forms.Label();
            this.lblLevel = new System.Windows.Forms.Label();
            this.lstSubject = new System.Windows.Forms.ListBox();
            this.lstLevel = new System.Windows.Forms.ListBox();
            this.btnAssign = new System.Windows.Forms.Button();
            this.cmbTutor = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lblAssign
            // 
            this.lblAssign.AutoSize = true;
            this.lblAssign.Font = new System.Drawing.Font("Rockwell", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblAssign.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblAssign.Location = new System.Drawing.Point(481, 76);
            this.lblAssign.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblAssign.Name = "lblAssign";
            this.lblAssign.Size = new System.Drawing.Size(325, 59);
            this.lblAssign.TabIndex = 0;
            this.lblAssign.Text = "Assign Tutor";
            // 
            // lblAssignName
            // 
            this.lblAssignName.AutoSize = true;
            this.lblAssignName.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblAssignName.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblAssignName.Location = new System.Drawing.Point(76, 222);
            this.lblAssignName.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblAssignName.Name = "lblAssignName";
            this.lblAssignName.Size = new System.Drawing.Size(168, 33);
            this.lblAssignName.TabIndex = 1;
            this.lblAssignName.Text = "Tutor Name : ";
            // 
            // lblAssignNum
            // 
            this.lblAssignNum.AutoSize = true;
            this.lblAssignNum.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblAssignNum.Location = new System.Drawing.Point(76, 305);
            this.lblAssignNum.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblAssignNum.Name = "lblAssignNum";
            this.lblAssignNum.Size = new System.Drawing.Size(0, 33);
            this.lblAssignNum.TabIndex = 2;
            // 
            // lblSubject
            // 
            this.lblSubject.AutoSize = true;
            this.lblSubject.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblSubject.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblSubject.Location = new System.Drawing.Point(76, 383);
            this.lblSubject.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblSubject.Name = "lblSubject";
            this.lblSubject.Size = new System.Drawing.Size(121, 33);
            this.lblSubject.TabIndex = 3;
            this.lblSubject.Text = "Subject : ";
            // 
            // lblLevel
            // 
            this.lblLevel.AutoSize = true;
            this.lblLevel.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblLevel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblLevel.Location = new System.Drawing.Point(76, 533);
            this.lblLevel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblLevel.Name = "lblLevel";
            this.lblLevel.Size = new System.Drawing.Size(97, 33);
            this.lblLevel.TabIndex = 4;
            this.lblLevel.Text = "Level : ";
            // 
            // lstSubject
            // 
            this.lstSubject.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.lstSubject.FormattingEnabled = true;
            this.lstSubject.ItemHeight = 31;
            this.lstSubject.Items.AddRange(new object[] {
            "English",
            "Chinese",
            "Malay",
            "Maths",
            "Chemistry",
            "Biology",
            "Physic",
            "Addmaths"});
            this.lstSubject.Location = new System.Drawing.Point(332, 383);
            this.lstSubject.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.lstSubject.Name = "lstSubject";
            this.lstSubject.Size = new System.Drawing.Size(296, 97);
            this.lstSubject.TabIndex = 6;
            // 
            // lstLevel
            // 
            this.lstLevel.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.lstLevel.FormattingEnabled = true;
            this.lstLevel.ItemHeight = 31;
            this.lstLevel.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.lstLevel.Location = new System.Drawing.Point(332, 533);
            this.lstLevel.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.lstLevel.Name = "lstLevel";
            this.lstLevel.Size = new System.Drawing.Size(134, 97);
            this.lstLevel.TabIndex = 7;
            // 
            // btnAssign
            // 
            this.btnAssign.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnAssign.Location = new System.Drawing.Point(979, 685);
            this.btnAssign.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.btnAssign.Name = "btnAssign";
            this.btnAssign.Size = new System.Drawing.Size(188, 45);
            this.btnAssign.TabIndex = 8;
            this.btnAssign.Text = "Assign";
            this.btnAssign.UseVisualStyleBackColor = true;
            this.btnAssign.Click += new System.EventHandler(this.btnAssign_Click);
            // 
            // cmbTutor
            // 
            this.cmbTutor.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.cmbTutor.FormattingEnabled = true;
            this.cmbTutor.Location = new System.Drawing.Point(331, 222);
            this.cmbTutor.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cmbTutor.Name = "cmbTutor";
            this.cmbTutor.Size = new System.Drawing.Size(297, 39);
            this.cmbTutor.TabIndex = 9;
            this.cmbTutor.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // FormAssign
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.ClientSize = new System.Drawing.Size(1274, 829);
            this.Controls.Add(this.cmbTutor);
            this.Controls.Add(this.btnAssign);
            this.Controls.Add(this.lstLevel);
            this.Controls.Add(this.lstSubject);
            this.Controls.Add(this.lblLevel);
            this.Controls.Add(this.lblSubject);
            this.Controls.Add(this.lblAssignNum);
            this.Controls.Add(this.lblAssignName);
            this.Controls.Add(this.lblAssign);
            this.Font = new System.Drawing.Font("Rockwell", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Name = "FormAssign";
            this.Text = "FormAssign";
            this.Load += new System.EventHandler(this.FormAssign_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblAssign;
        private Label lblAssignName;
        private Label lblAssignNum;
        private Label lblSubject;
        private Label lblLevel;
        private ListBox lstSubject;
        private ListBox lstLevel;
        private Button btnAssign;
        private ComboBox cmbTutor;
    }
}