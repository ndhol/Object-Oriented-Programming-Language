﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace IOOP_Assignment
{
    public partial class EditProfile : Form
    {
        public static string name;
        public static string email;
        public static string phoneNum;

        public EditProfile(string n)
        {
            InitializeComponent();
            name = n;
            txtName.Text = name;
        }

        public EditProfile(string n, string em, string p)
        {
            InitializeComponent();
            name = n;
            email = em;
            phoneNum = p;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Profile frm= new Profile(name,"receptionist");
            frm.Show(); 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            User o1 = new User (name, email, phoneNum);
            MessageBox.Show(o1.editProfile(txtName.Text, txtEmail.Text, txtPhone.Text));
        }

        private void EditProfile_Load(object sender, EventArgs e)
        {
            User o1 = new User(name);
            User.viewProfile(o1);
            txtEmail.Text = o1.Email;
            txtPhone.Text = o1.PhoneNum;
        }

        //edit button not working but view profile working 
    }
}
