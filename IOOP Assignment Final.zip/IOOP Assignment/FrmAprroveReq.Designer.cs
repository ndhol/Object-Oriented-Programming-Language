﻿namespace IOOP_Assignment
{
    partial class FrmAprroveReq
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbName = new System.Windows.Forms.ComboBox();
            this.lBRequest = new System.Windows.Forms.ListBox();
            this.btnApprove = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cmbName
            // 
            this.cmbName.FormattingEnabled = true;
            this.cmbName.Location = new System.Drawing.Point(496, 131);
            this.cmbName.Name = "cmbName";
            this.cmbName.Size = new System.Drawing.Size(242, 40);
            this.cmbName.TabIndex = 0;
            this.cmbName.SelectedIndexChanged += new System.EventHandler(this.cmbName_SelectedIndexChanged);
            // 
            // lBRequest
            // 
            this.lBRequest.FormattingEnabled = true;
            this.lBRequest.ItemHeight = 32;
            this.lBRequest.Location = new System.Drawing.Point(276, 226);
            this.lBRequest.Name = "lBRequest";
            this.lBRequest.Size = new System.Drawing.Size(700, 292);
            this.lBRequest.TabIndex = 1;
            this.lBRequest.SelectedIndexChanged += new System.EventHandler(this.lBRequest_SelectedIndexChanged);
            // 
            // btnApprove
            // 
            this.btnApprove.Location = new System.Drawing.Point(547, 595);
            this.btnApprove.Name = "btnApprove";
            this.btnApprove.Size = new System.Drawing.Size(150, 46);
            this.btnApprove.TabIndex = 2;
            this.btnApprove.Text = "Approve";
            this.btnApprove.UseVisualStyleBackColor = true;
            this.btnApprove.Click += new System.EventHandler(this.btnApprove_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Rockwell", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(496, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(241, 59);
            this.label1.TabIndex = 3;
            this.label1.Text = "Requests";
            // 
            // FrmAprroveReq
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SandyBrown;
            this.ClientSize = new System.Drawing.Size(1274, 829);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnApprove);
            this.Controls.Add(this.lBRequest);
            this.Controls.Add(this.cmbName);
            this.Name = "FrmAprroveReq";
            this.Text = "FrmAprroveReq";
            this.Load += new System.EventHandler(this.FrmAprroveReq_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ComboBox cmbName;
        private ListBox lBRequest;
        private Button btnApprove;
        private Label label1;
    }
}