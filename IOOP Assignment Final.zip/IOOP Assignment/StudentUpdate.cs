﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace IOOP_Assignment
{
    public partial class StudentUpdate : Form
    {
        private string name;
        public StudentUpdate()
        {
            InitializeComponent();
        }

        private void StudentUpdate_Load(object sender, EventArgs e)
        {
            int count;
            ArrayList names = new ArrayList();
            Receptionist students = new Receptionist();
            names = students.viewStudent();
            foreach (var i in names) 
            {
                 comboBox1.Items.Add(i);
                
            }
        }

        private void chklstSub_SelectedIndexChanged(object sender, EventArgs e)
        {
            int count;
            Receptionist r = new Receptionist(name);
            count = r.checkEnrol();
            if (chklstSub.SelectedIndex > count)
            {
                MessageBox.Show("Maximum choose only 3 subjects.");
                chklstSub.ClearSelected();
            }



        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            name = comboBox1.Text;
            




        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string sub1;
            string sub2;
            string sub3;
            string level=cmbLevel.Text;
            Receptionist r = new Receptionist(name);
            ArrayList sub = new ArrayList();
            foreach (String s in chklstSub.CheckedItems)
            {
                sub.Add(s);
            }
            
            if (sub.Count == 1)
            {
                sub1 = (string)sub[0];
                sub2 = null;
                sub3 = null;
                Receptionist subject = new Receptionist(name, level, sub1, sub2, sub3);
                string status = subject.subject();
                MessageBox.Show(status);

            }
            else if (sub.Count == 2)
            {
                sub1 = (string)sub[0];
                sub2 = (string)sub[1];
                sub3 = null;
                Receptionist subject = new Receptionist(name, level, sub1, sub2, sub3);
                string status = subject.subject();
                MessageBox.Show(status);
            }

            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
