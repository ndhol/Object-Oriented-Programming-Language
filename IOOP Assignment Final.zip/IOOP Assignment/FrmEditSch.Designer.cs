﻿namespace IOOP_Assignment
{
    partial class FrmEditSch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCon = new System.Windows.Forms.Button();
            this.lblChange = new System.Windows.Forms.Label();
            this.cmbAddTime = new System.Windows.Forms.ComboBox();
            this.cmbAddDay = new System.Windows.Forms.ComboBox();
            this.lblTime = new System.Windows.Forms.Label();
            this.lblDay = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnCon
            // 
            this.btnCon.Location = new System.Drawing.Point(959, 720);
            this.btnCon.Name = "btnCon";
            this.btnCon.Size = new System.Drawing.Size(162, 39);
            this.btnCon.TabIndex = 1;
            this.btnCon.Text = "Confirm";
            this.btnCon.UseVisualStyleBackColor = true;
            // 
            // lblChange
            // 
            this.lblChange.AutoSize = true;
            this.lblChange.Location = new System.Drawing.Point(163, 598);
            this.lblChange.Name = "lblChange";
            this.lblChange.Size = new System.Drawing.Size(66, 27);
            this.lblChange.TabIndex = 3;
            this.lblChange.Text = "Add:";
            // 
            // cmbAddTime
            // 
            this.cmbAddTime.FormattingEnabled = true;
            this.cmbAddTime.Items.AddRange(new object[] {
            "9.00am-11.00am",
            "11.30am-1.30pm",
            "2.00pm-4.00pm",
            "4.30pm-6.30pm",
            "7.00pm-9.00pm",
            "9.00pm-11.00pm"});
            this.cmbAddTime.Location = new System.Drawing.Point(645, 598);
            this.cmbAddTime.Name = "cmbAddTime";
            this.cmbAddTime.Size = new System.Drawing.Size(260, 35);
            this.cmbAddTime.TabIndex = 6;
            // 
            // cmbAddDay
            // 
            this.cmbAddDay.FormattingEnabled = true;
            this.cmbAddDay.Items.AddRange(new object[] {
            "Sunday",
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday ",
            "Saturday "});
            this.cmbAddDay.Location = new System.Drawing.Point(310, 598);
            this.cmbAddDay.Name = "cmbAddDay";
            this.cmbAddDay.Size = new System.Drawing.Size(260, 35);
            this.cmbAddDay.TabIndex = 7;
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Location = new System.Drawing.Point(712, 529);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(68, 27);
            this.lblTime.TabIndex = 8;
            this.lblTime.Text = "Time";
            // 
            // lblDay
            // 
            this.lblDay.AutoSize = true;
            this.lblDay.Location = new System.Drawing.Point(407, 529);
            this.lblDay.Name = "lblDay";
            this.lblDay.Size = new System.Drawing.Size(57, 27);
            this.lblDay.TabIndex = 9;
            this.lblDay.Text = "Day";
            
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 27;
            this.listBox1.Location = new System.Drawing.Point(220, 105);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(815, 382);
            this.listBox1.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(489, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(257, 27);
            this.label1.TabIndex = 11;
            this.label1.Text = "Unavailable Timeslots";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(175, 790);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 27);
            this.label2.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(172, 571);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 27);
            this.label3.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(162, 723);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 27);
            this.label4.TabIndex = 14;
            this.label4.Text = "Delete:";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Sunday",
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday ",
            "Saturday "});
            this.comboBox1.Location = new System.Drawing.Point(309, 723);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(260, 35);
            this.comboBox1.TabIndex = 15;
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "Sunday",
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday ",
            "Saturday "});
            this.comboBox4.Location = new System.Drawing.Point(644, 720);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(260, 35);
            this.comboBox4.TabIndex = 16;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(960, 598);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(162, 39);
            this.button1.TabIndex = 17;
            this.button1.Text = "Confirm";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // FrmEditSch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 27F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1274, 829);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.comboBox4);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.lblDay);
            this.Controls.Add(this.lblTime);
            this.Controls.Add(this.cmbAddDay);
            this.Controls.Add(this.cmbAddTime);
            this.Controls.Add(this.lblChange);
            this.Controls.Add(this.btnCon);
            this.Font = new System.Drawing.Font("Rockwell", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Name = "FrmEditSch";
            this.Text = "Schedule Editor";
            this.Load += new System.EventHandler(this.FrmEditSch_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Button btnCon;
        private Label lblChange;
        private ComboBox cmbAddTime;
        private ComboBox cmbAddDay;
        private Label lblTime;
        private Label lblDay;
        private ListBox listBox1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private ComboBox comboBox1;
        private ComboBox comboBox4;
        private Button button1;
    }
}