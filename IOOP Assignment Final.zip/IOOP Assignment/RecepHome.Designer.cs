﻿namespace IOOP_Assignment
{
    partial class RecepHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.gbstudent = new System.Windows.Forms.GroupBox();
            this.btnReq = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnPay = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnreg = new System.Windows.Forms.Button();
            this.btnEditProfile = new System.Windows.Forms.Button();
            this.gbstudent.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Rockwell", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(463, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(364, 46);
            this.label1.TabIndex = 0;
            this.label1.Text = "Receptionist Home";
            // 
            // gbstudent
            // 
            this.gbstudent.Controls.Add(this.btnReq);
            this.gbstudent.Controls.Add(this.btnDelete);
            this.gbstudent.Controls.Add(this.btnPay);
            this.gbstudent.Controls.Add(this.btnUpdate);
            this.gbstudent.Controls.Add(this.btnreg);
            this.gbstudent.Location = new System.Drawing.Point(436, 186);
            this.gbstudent.Name = "gbstudent";
            this.gbstudent.Size = new System.Drawing.Size(419, 370);
            this.gbstudent.TabIndex = 1;
            this.gbstudent.TabStop = false;
            this.gbstudent.Text = "Student";
            // 
            // btnReq
            // 
            this.btnReq.Location = new System.Drawing.Point(128, 294);
            this.btnReq.Name = "btnReq";
            this.btnReq.Size = new System.Drawing.Size(162, 39);
            this.btnReq.TabIndex = 4;
            this.btnReq.Text = "Request";
            this.btnReq.UseVisualStyleBackColor = true;
            this.btnReq.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(128, 127);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(162, 39);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnPay
            // 
            this.btnPay.Location = new System.Drawing.Point(128, 241);
            this.btnPay.Name = "btnPay";
            this.btnPay.Size = new System.Drawing.Size(162, 39);
            this.btnPay.TabIndex = 2;
            this.btnPay.Text = "Payment";
            this.btnPay.UseVisualStyleBackColor = true;
            this.btnPay.Click += new System.EventHandler(this.btnPay_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(128, 186);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(162, 39);
            this.btnUpdate.TabIndex = 1;
            this.btnUpdate.Text = "Update Subject";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnreg
            // 
            this.btnreg.Location = new System.Drawing.Point(128, 61);
            this.btnreg.Name = "btnreg";
            this.btnreg.Size = new System.Drawing.Size(162, 39);
            this.btnreg.TabIndex = 0;
            this.btnreg.Text = "Register";
            this.btnreg.UseVisualStyleBackColor = true;
            this.btnreg.Click += new System.EventHandler(this.btnreg_Click);
            // 
            // btnEditProfile
            // 
            this.btnEditProfile.Location = new System.Drawing.Point(1002, 104);
            this.btnEditProfile.Name = "btnEditProfile";
            this.btnEditProfile.Size = new System.Drawing.Size(162, 39);
            this.btnEditProfile.TabIndex = 2;
            this.btnEditProfile.Text = "Edit Profile";
            this.btnEditProfile.UseVisualStyleBackColor = true;
            this.btnEditProfile.Click += new System.EventHandler(this.btnEditProfile_Click);
            // 
            // RecepHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 27F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.ClientSize = new System.Drawing.Size(1274, 699);
            this.Controls.Add(this.btnEditProfile);
            this.Controls.Add(this.gbstudent);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Rockwell", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Name = "RecepHome";
            this.Text = "RecepHome";
            this.gbstudent.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private GroupBox gbstudent;
        private Button btnPay;
        private Button btnUpdate;
        private Button btnreg;
        private Button btnEditProfile;
        private Button btnDelete;
        private Button btnReq;
    }
}