﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace IOOP_Assignment
{
    public partial class FormDeleteTutor : Form
    {
        public FormDeleteTutor()
        {
            InitializeComponent();
        }

        private void cmbTutorName_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void FormDeleteTutor_Load(object sender, EventArgs e)
        {
            ArrayList name = new ArrayList();
            name = Admin.viewAlltutor();
           
            foreach (var item in name)
            {
               cmbTutorName.Items.Add(item);
            }
        }

        private void btnDeleteTutor_Click(object sender, EventArgs e)
        {
            string name=cmbTutorName.Text;
            Admin delete = new Admin(name);
            string status=delete.deleteTutor();
            MessageBox.Show(status);
            FormDeleteTutor_Load(sender, e);
        }
    }
}
