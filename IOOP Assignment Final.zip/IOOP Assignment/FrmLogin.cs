namespace IOOP_Assignment
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string stat;
            string u=txtUsername.Text;
            string p=txtPassword.Text;

            User obj1 = new User(u,p);
            stat = obj1.login(txtUsername.Text);
            if (stat != null) 
            { MessageBox.Show(stat);
            }
            
            txtUsername.Text = String.Empty;
            txtPassword.Text = String.Empty;

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}