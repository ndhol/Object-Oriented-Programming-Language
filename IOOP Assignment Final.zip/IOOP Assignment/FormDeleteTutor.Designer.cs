﻿namespace IOOP_Assignment
{
    partial class FormDeleteTutor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.cmbTutorName = new System.Windows.Forms.ComboBox();
            this.btnDeleteTutor = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Tomato;
            this.label1.Font = new System.Drawing.Font("Rockwell", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(452, 82);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(322, 59);
            this.label1.TabIndex = 0;
            this.label1.Text = "Delete Tutor";
            // 
            // cmbTutorName
            // 
            this.cmbTutorName.FormattingEnabled = true;
            this.cmbTutorName.Location = new System.Drawing.Point(495, 185);
            this.cmbTutorName.Name = "cmbTutorName";
            this.cmbTutorName.Size = new System.Drawing.Size(242, 40);
            this.cmbTutorName.TabIndex = 1;
            this.cmbTutorName.SelectedIndexChanged += new System.EventHandler(this.cmbTutorName_SelectedIndexChanged);
            // 
            // btnDeleteTutor
            // 
            this.btnDeleteTutor.Location = new System.Drawing.Point(539, 494);
            this.btnDeleteTutor.Name = "btnDeleteTutor";
            this.btnDeleteTutor.Size = new System.Drawing.Size(150, 46);
            this.btnDeleteTutor.TabIndex = 2;
            this.btnDeleteTutor.Text = "Delete";
            this.btnDeleteTutor.UseVisualStyleBackColor = true;
            this.btnDeleteTutor.Click += new System.EventHandler(this.btnDeleteTutor_Click);
            // 
            // FormDeleteTutor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSalmon;
            this.ClientSize = new System.Drawing.Size(1274, 829);
            this.Controls.Add(this.btnDeleteTutor);
            this.Controls.Add(this.cmbTutorName);
            this.Controls.Add(this.label1);
            this.Name = "FormDeleteTutor";
            this.Text = "FormDeleteTutor";
            this.Load += new System.EventHandler(this.FormDeleteTutor_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private ComboBox cmbTutorName;
        private Button btnDeleteTutor;
    }
}