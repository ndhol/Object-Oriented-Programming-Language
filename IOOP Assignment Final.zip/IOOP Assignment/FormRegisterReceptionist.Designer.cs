﻿namespace IOOP_Assignment
{
    partial class FormRegisterReceptionist
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblRegisterRecep = new System.Windows.Forms.Label();
            this.btnRegisterRecep = new System.Windows.Forms.Button();
            this.lblRegisterName = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblIC = new System.Windows.Forms.Label();
            this.lblAddress = new System.Windows.Forms.Label();
            this.lblContact = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtIC = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtContact = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblRegisterRecep
            // 
            this.lblRegisterRecep.AutoSize = true;
            this.lblRegisterRecep.Font = new System.Drawing.Font("Rockwell", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRegisterRecep.Location = new System.Drawing.Point(363, 61);
            this.lblRegisterRecep.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblRegisterRecep.Name = "lblRegisterRecep";
            this.lblRegisterRecep.Size = new System.Drawing.Size(536, 59);
            this.lblRegisterRecep.TabIndex = 0;
            this.lblRegisterRecep.Text = "Register Receptionist";
            // 
            // btnRegisterRecep
            // 
            this.btnRegisterRecep.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnRegisterRecep.Location = new System.Drawing.Point(924, 605);
            this.btnRegisterRecep.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.btnRegisterRecep.Name = "btnRegisterRecep";
            this.btnRegisterRecep.Size = new System.Drawing.Size(165, 39);
            this.btnRegisterRecep.TabIndex = 1;
            this.btnRegisterRecep.Text = "Register";
            this.btnRegisterRecep.UseVisualStyleBackColor = true;
            this.btnRegisterRecep.Click += new System.EventHandler(this.btnRegisterRecep_Click);
            // 
            // lblRegisterName
            // 
            this.lblRegisterName.AutoSize = true;
            this.lblRegisterName.Font = new System.Drawing.Font("Rockwell", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblRegisterName.Location = new System.Drawing.Point(86, 225);
            this.lblRegisterName.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblRegisterName.Name = "lblRegisterName";
            this.lblRegisterName.Size = new System.Drawing.Size(107, 31);
            this.lblRegisterName.TabIndex = 2;
            this.lblRegisterName.Text = "Name : ";
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtName.ForeColor = System.Drawing.Color.Silver;
            this.txtName.Location = new System.Drawing.Point(228, 227);
            this.txtName.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(216, 35);
            this.txtName.TabIndex = 3;
            // 
            // lblIC
            // 
            this.lblIC.AutoSize = true;
            this.lblIC.Location = new System.Drawing.Point(86, 301);
            this.lblIC.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblIC.Name = "lblIC";
            this.lblIC.Size = new System.Drawing.Size(154, 27);
            this.lblIC.TabIndex = 6;
            this.lblIC.Text = "IC Number : ";
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new System.Drawing.Point(86, 362);
            this.lblAddress.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(124, 27);
            this.lblAddress.TabIndex = 7;
            this.lblAddress.Text = "Address : ";
            // 
            // lblContact
            // 
            this.lblContact.AutoSize = true;
            this.lblContact.Location = new System.Drawing.Point(699, 227);
            this.lblContact.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblContact.Name = "lblContact";
            this.lblContact.Size = new System.Drawing.Size(215, 27);
            this.lblContact.TabIndex = 8;
            this.lblContact.Text = "Contact Number : ";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(699, 298);
            this.lblEmail.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(193, 27);
            this.lblEmail.TabIndex = 9;
            this.lblEmail.Text = "Email Address : ";
            // 
            // txtIC
            // 
            this.txtIC.Location = new System.Drawing.Point(246, 298);
            this.txtIC.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.txtIC.Name = "txtIC";
            this.txtIC.Size = new System.Drawing.Size(216, 36);
            this.txtIC.TabIndex = 10;
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(244, 362);
            this.txtAddress.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(384, 36);
            this.txtAddress.TabIndex = 11;
            // 
            // txtContact
            // 
            this.txtContact.Location = new System.Drawing.Point(944, 222);
            this.txtContact.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.txtContact.Name = "txtContact";
            this.txtContact.Size = new System.Drawing.Size(216, 36);
            this.txtContact.TabIndex = 12;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(944, 292);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(216, 36);
            this.txtEmail.TabIndex = 13;
            // 
            // FormRegisterReceptionist
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 27F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Khaki;
            this.ClientSize = new System.Drawing.Size(1274, 829);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.txtContact);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.txtIC);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.lblContact);
            this.Controls.Add(this.lblAddress);
            this.Controls.Add(this.lblIC);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblRegisterName);
            this.Controls.Add(this.btnRegisterRecep);
            this.Controls.Add(this.lblRegisterRecep);
            this.Font = new System.Drawing.Font("Rockwell", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "FormRegisterReceptionist";
            this.Text = "FormRegisterRecep";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblRegisterRecep;
        private Button btnRegisterRecep;
        private Label lblRegisterName;
        private TextBox txtName;
        private Label lblIC;
        private Label lblAddress;
        private Label lblContact;
        private Label lblEmail;
        private TextBox txtIC;
        private TextBox txtAddress;
        private TextBox txtContact;
        private TextBox txtEmail;
    }
}