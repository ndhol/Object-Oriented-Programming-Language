﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment
{
    public partial class frm_Request : Form
    {
        private string name;
        Receptionist req = new Receptionist();
        public frm_Request(string n)
        {
            InitializeComponent();
            name = n;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frm_StudentPanel f2 = new frm_StudentPanel(name);
            f2.ShowDialog();
        }

        private void btn_Send_Click(object sender, EventArgs e)
        {
            string request=txtr.Text;
            Student o1= new Student(name);
            string status= o1.addRequest(request);
            MessageBox.Show(status);
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            
            string status=req.approveReq(name);
        }

        private void frm_Request_Load(object sender, EventArgs e)
        {
            
            
        }
    }
}
