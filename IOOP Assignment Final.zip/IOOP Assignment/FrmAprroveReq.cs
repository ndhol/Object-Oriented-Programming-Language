﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment
{
    public partial class FrmAprroveReq : Form
    {
        Receptionist students = new Receptionist();
        public FrmAprroveReq()
        {
            InitializeComponent();
        }

        private void cmbName_SelectedIndexChanged(object sender, EventArgs e)
        {
            lBRequest.Items.Clear();
            string name = cmbName.Text;
            string request = students.viewReq(name);
            lBRequest.Items.Add(request);

        }

        private void FrmAprroveReq_Load(object sender, EventArgs e)
        {
            ArrayList names = new ArrayList();
            
            names = students.viewStudent();
            foreach (var i in names)
            {
                cmbName.Items.Add(i);

            }
        }

        private void lBRequest_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void btnApprove_Click(object sender, EventArgs e)
        {
            string name = cmbName.Text;
            string status = students.approveReq(name);
            MessageBox.Show(status);
        }
    }
}
