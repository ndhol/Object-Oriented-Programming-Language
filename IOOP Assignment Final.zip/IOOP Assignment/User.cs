﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace IOOP_Assignment
{
    internal class User
    {
        private string name;
        private string email;
        private string phoneNum;
        private string username;
        private string password;

        public User(string n)
        {
            name = n;
        }

        public User(string u,string p)
        {
            username = u;
            password= p;
        }

        public User(string Name, string Email, string PhoneNum) 
        {
            name = Name;
            email = Email;
            phoneNum = PhoneNum;
        }
        public string login(string un)
        {
            
            string status = null;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
            con.Open();



            SqlCommand cmd = new SqlCommand("select count (*) from users where username= '" + username + "' and password= '" + password + "'", con);

            int count = Convert.ToInt32(cmd.ExecuteScalar().ToString());
            if (count > 0)

            {
                SqlCommand cmd2 = new SqlCommand("Select role from users where username = '" + username + "' and password= '" + password + "'", con);
                string userRole = cmd2.ExecuteScalar().ToString();
                if (userRole == "admin")
                {
                    AdminHome a = new AdminHome(un);
                    a.ShowDialog();
                }

                else if (userRole == "receptionist")
                {
                    RecepHome a = new RecepHome(un);
                    a.ShowDialog();
                }

                else if (userRole == "tutor")
                {
                    FrmTutorHome t = new FrmTutorHome(un);
                    t.ShowDialog();
                }
                else if (userRole == "student")
                {
                    frm_StudentPanel s = new frm_StudentPanel(un);
                    s.ShowDialog();
                }

            }
            else
                status = "Incorrect username/password";
            con.Close();

            return status;


        }

        public string Email { get => email; set => email = value; }
        public string PhoneNum { get => phoneNum; set => phoneNum = value; }
        public string Name { get => name; set => name = value; }

        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
        
        public string editProfile(string n, string em, string p)
        {
            string status;
            con.Open();

            name = n;
            email = em;
            phoneNum = p;

            SqlCommand cmd = new SqlCommand("update staff set name = @nm, email =@em, contactNum=@p where name = @nm", con);
            
            cmd.Parameters.AddWithValue("@nm", name);
            cmd.Parameters.AddWithValue("@em", email);
            cmd.Parameters.AddWithValue("@p", phoneNum);

            int i = cmd.ExecuteNonQuery();
            if (i != 0)
                status = "Update Succesfully.";
            else
                status = "unable to update.";
            con.Close();

            return status;

        }

        public static void viewProfile (User obj1)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select contactNum, email from staff where name = @a", con);
            cmd.Parameters.AddWithValue("@a", obj1.Name);

            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                obj1.PhoneNum = rd.GetString(0);
                obj1.Email = rd.GetString(1);
                
            }
            con.Close();
        }
    }
}
