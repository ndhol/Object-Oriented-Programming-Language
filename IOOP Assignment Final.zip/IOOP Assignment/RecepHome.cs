﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment
{
    public partial class RecepHome : Form
    {
        private string name;
        public RecepHome(string n)
        {
            InitializeComponent();
            name=n;

        }

        private void btnreg_Click(object sender, EventArgs e)
        {
            Register frm= new Register();
            frm.ShowDialog();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DeleteStudent frm= new DeleteStudent();
            frm.ShowDialog();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            StudentUpdate frm= new StudentUpdate();
            frm.ShowDialog();
        }

        private void btnPay_Click(object sender, EventArgs e)
        {
            Payment frm= new Payment();
            frm.ShowDialog();
        }

        private void btnEditProfile_Click(object sender, EventArgs e)
        {
            EditProfile frm= new EditProfile(name);
            frm.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            FrmAprroveReq frm = new FrmAprroveReq();
            frm.ShowDialog();
        }
    }
}
