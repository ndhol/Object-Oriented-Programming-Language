﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace IOOP_Assignment
{
    public partial class FormAssign : Form
    {
        
        public FormAssign()
        {
            InitializeComponent();
        }

        private void btnAssign_Click(object sender, EventArgs e)
        {
            Admin obj1 = new Admin(cmbTutor.Text,lstSubject.Text,lstLevel.Text);
            MessageBox.Show(obj1.assignTutor());
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void FormAssign_Load(object sender, EventArgs e)
        {
            ArrayList name = new ArrayList();
            name = Admin.viewAlltutor();

            foreach (var item in name)
            {
                cmbTutor.Items.Add(item);
            }
        }
    
    }
}
