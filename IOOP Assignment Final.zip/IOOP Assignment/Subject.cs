﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment
{
    public partial class Subject : Form
    {
        private string name;
        public Subject(string n)
        {
            InitializeComponent();
            name= n;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void chklstSub_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (chklstSub.SelectedIndex > 3)
                MessageBox.Show("Maximum choose only 3 subjects.");
            
        }

        private void btnDone_Click(object sender, EventArgs e)
        {
            string level = cmbLevel.Text;
            string sub1;
            string sub2;
            string sub3;
            ArrayList sub = new ArrayList();
            foreach (String s in chklstSub.CheckedItems)
            {
                sub.Add(s);
            }
            if (sub.Count<1) 
            {
                MessageBox.Show("Pick a class");
            }
            if (sub.Count == 1)
            {
                sub1 = (string)sub[0];
                sub2 = null;
                sub3 = null;
                Receptionist subject = new Receptionist(name, level, sub1, sub2, sub3);
                string status = subject.subject();

            }
            else if (sub.Count == 2)
            {
                sub1 = (string)sub[0];
                sub2 = (string)sub[1];
                sub3 = null;
                Receptionist subject = new Receptionist(name, level, sub1, sub2, sub3);
                string status = subject.subject();
            }
            else if (sub.Count == 3)
            {
                sub1 = (string)sub[0];
                sub2 = (string)sub[1];
                sub3 = (string)sub[2];
                Receptionist subject = new Receptionist(name, level, sub1, sub2, sub3);
                string status = subject.subject();
            }
            else
            {
                MessageBox.Show("Pick only up to 3 classes");
                
            }
             
            
        }

        private void Subject_Load(object sender, EventArgs e)
        {

        }

        private void cmbName_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
