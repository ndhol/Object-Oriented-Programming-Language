﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Schema;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace IOOP_Assignment
{
    public partial class Payment : Form
    {
        
        public Payment()
        {
            InitializeComponent();

        }

        private void btnPay_Click(object sender, EventArgs e)
        {
            string name = cmbName.Text;
            Receptionist payment = new Receptionist(name);
            string status = payment.Payment(cmbMonth.Text);
            MessageBox.Show(status);
            cmbName_SelectedIndexChanged(sender, e);
        }

        private void btnPay_Click(object sender, EventArgs e, ListBox lstSub)
        {



            
            
        }

        private void cmbName_SelectedIndexChanged(object sender, EventArgs e)
        {
            int total = 0;
            lstSub.Items.Clear();
            string n;
            int num;
            
            ArrayList info = new ArrayList();
            ArrayList charge = new ArrayList();
            string name = cmbName.Text;
            Receptionist payment = new Receptionist(name);
            info = payment.viewCharge();
           
            foreach (var i in info) 
            {
                lstSub.Items.Add(i);
            }

            charge = payment.viewTotal();
            foreach (var i in charge)
            {
                n = i.ToString();
                num= int.Parse(n);
                total += num;
            }
            lblTotal.Text = "The total is RM"+total;



        }

        private void Payment_Load(object sender, EventArgs e)
        {
            
            ArrayList names = new ArrayList();
            Receptionist obj1 = new Receptionist();
            names = obj1.viewStudent();
            foreach (var i in names)
            {
                cmbName.Items.Add(i);

            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
