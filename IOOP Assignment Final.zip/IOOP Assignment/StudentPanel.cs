﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment
{
    public partial class frm_StudentPanel : Form
    {
        private string name;
        public frm_StudentPanel(string n)
        {
            InitializeComponent();
            name=n;
        }

        private void btn_EditProfile_Click(object sender, EventArgs e)
        {
            frm_ProfileEdit f1= new frm_ProfileEdit();
            f1.ShowDialog();
        }

        private void btn_Send_Click(object sender, EventArgs e)
        {
            
        }

        private void lbl_Name_Click(object sender, EventArgs e)
        {

        }

        private void frm_StudentPanel_Load(object sender, EventArgs e)
        {
            
        }

        private void btn_Send_Click_1(object sender, EventArgs e)
        {
            frm_Request f2 = new frm_Request(name);
            f2.ShowDialog();
        }


        private void TimeSchedule_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            Student obj1 = new Student(name);
            
        }

        private void frm_StudentPanel_Load_1(object sender, EventArgs e)
        {
            Student obj1 = new Student(name);
            ArrayList ListTimeSchedule = new ArrayList();
            //calling static method require className.method(..)
            //pass object obj1 to method viewProfile
            Student.viewProfile(obj1);
            lbl_Month.Text = obj1.Month1;
            lbl_Name.Text = obj1.Name1;
            lblAddress.Text = obj1.Address1;
            lblEmail.Text = obj1.Email1;
            lblContactNumber.Text = obj1.PhoneNumber1;
            ListTimeSchedule=Student.viewSch(obj1);
            foreach (string Subject in ListTimeSchedule)
            {
                TimeSchedule.Items.Add(Subject);
            }
            //Student.viewsubjecttimeschedule(obj1);

            /*ArrayList ListTimeSchedule = new ArrayList();
            Student.viewdaytimeschedule(obj1);
            TimeSchedule.Items.Add(obj1.TimeSchedule1);*/



            /*(
            */


        }

        private void btn_EditProfile_Click_1(object sender, EventArgs e)
        {
            frm_ProfileEdit frm = new frm_ProfileEdit(name);
            frm.ShowDialog();
        }
    }
}
