﻿namespace IOOP_Assignment
{
    partial class FrmTutorHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmTutorHome));
            this.lblTitle = new System.Windows.Forms.Label();
            this.pBoxClassInfo = new System.Windows.Forms.PictureBox();
            this.pBoxEnrol = new System.Windows.Forms.PictureBox();
            this.pBoxTProfile = new System.Windows.Forms.PictureBox();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnClassInfo = new System.Windows.Forms.Button();
            this.btnEnrol = new System.Windows.Forms.Button();
            this.btnTProfile = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxClassInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxEnrol)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxTProfile)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.BackColor = System.Drawing.Color.IndianRed;
            this.lblTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTitle.Font = new System.Drawing.Font("Rockwell", 28.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(416, 38);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(439, 93);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Homepage";
            // 
            // pBoxClassInfo
            // 
            this.pBoxClassInfo.BackColor = System.Drawing.Color.IndianRed;
            this.pBoxClassInfo.Image = ((System.Drawing.Image)(resources.GetObject("pBoxClassInfo.Image")));
            this.pBoxClassInfo.Location = new System.Drawing.Point(25, 35);
            this.pBoxClassInfo.Name = "pBoxClassInfo";
            this.pBoxClassInfo.Size = new System.Drawing.Size(311, 344);
            this.pBoxClassInfo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pBoxClassInfo.TabIndex = 1;
            this.pBoxClassInfo.TabStop = false;
            // 
            // pBoxEnrol
            // 
            this.pBoxEnrol.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pBoxEnrol.Image = ((System.Drawing.Image)(resources.GetObject("pBoxEnrol.Image")));
            this.pBoxEnrol.Location = new System.Drawing.Point(20, 36);
            this.pBoxEnrol.Name = "pBoxEnrol";
            this.pBoxEnrol.Padding = new System.Windows.Forms.Padding(1);
            this.pBoxEnrol.Size = new System.Drawing.Size(320, 344);
            this.pBoxEnrol.TabIndex = 2;
            this.pBoxEnrol.TabStop = false;
            this.pBoxEnrol.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pBoxTProfile
            // 
            this.pBoxTProfile.Image = ((System.Drawing.Image)(resources.GetObject("pBoxTProfile.Image")));
            this.pBoxTProfile.Location = new System.Drawing.Point(36, 36);
            this.pBoxTProfile.Name = "pBoxTProfile";
            this.pBoxTProfile.Size = new System.Drawing.Size(295, 338);
            this.pBoxTProfile.TabIndex = 3;
            this.pBoxTProfile.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Coral;
            this.panel1.Controls.Add(this.pBoxEnrol);
            this.panel1.Location = new System.Drawing.Point(449, 179);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(364, 405);
            this.panel1.TabIndex = 5;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Teal;
            this.panel2.Controls.Add(this.pBoxTProfile);
            this.panel2.Location = new System.Drawing.Point(844, 179);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(364, 405);
            this.panel2.TabIndex = 6;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panel3.Controls.Add(this.pBoxClassInfo);
            this.panel3.Location = new System.Drawing.Point(57, 179);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(364, 405);
            this.panel3.TabIndex = 6;
            // 
            // btnClassInfo
            // 
            this.btnClassInfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnClassInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClassInfo.Font = new System.Drawing.Font("Rockwell", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnClassInfo.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnClassInfo.Location = new System.Drawing.Point(57, 611);
            this.btnClassInfo.Name = "btnClassInfo";
            this.btnClassInfo.Size = new System.Drawing.Size(364, 138);
            this.btnClassInfo.TabIndex = 7;
            this.btnClassInfo.Text = "Class Information";
            this.btnClassInfo.UseVisualStyleBackColor = false;
            this.btnClassInfo.Click += new System.EventHandler(this.btnClassInfo_Click);
            // 
            // btnEnrol
            // 
            this.btnEnrol.BackColor = System.Drawing.Color.Coral;
            this.btnEnrol.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEnrol.Font = new System.Drawing.Font("Rockwell", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnEnrol.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnEnrol.Location = new System.Drawing.Point(449, 611);
            this.btnEnrol.Name = "btnEnrol";
            this.btnEnrol.Size = new System.Drawing.Size(364, 138);
            this.btnEnrol.TabIndex = 8;
            this.btnEnrol.Text = "Student Enrolment";
            this.btnEnrol.UseVisualStyleBackColor = false;
            this.btnEnrol.Click += new System.EventHandler(this.btnEnrol_Click);
            // 
            // btnTProfile
            // 
            this.btnTProfile.BackColor = System.Drawing.Color.Teal;
            this.btnTProfile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTProfile.Font = new System.Drawing.Font("Rockwell", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnTProfile.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnTProfile.Location = new System.Drawing.Point(844, 611);
            this.btnTProfile.Name = "btnTProfile";
            this.btnTProfile.Size = new System.Drawing.Size(364, 138);
            this.btnTProfile.TabIndex = 9;
            this.btnTProfile.Text = "Tutor Profile";
            this.btnTProfile.UseVisualStyleBackColor = false;
            this.btnTProfile.Click += new System.EventHandler(this.btnTProfile_Click);
            // 
            // FrmTutorHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1274, 829);
            this.Controls.Add(this.btnTProfile);
            this.Controls.Add(this.btnEnrol);
            this.Controls.Add(this.btnClassInfo);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblTitle);
            this.Name = "FrmTutorHome";
            this.Text = "Home";
            this.Load += new System.EventHandler(this.FrmTutorHome_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pBoxClassInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxEnrol)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxTProfile)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblTitle;
        private PictureBox pBoxClassInfo;
        private PictureBox pBoxEnrol;
        private PictureBox pBoxTProfile;
        private BindingSource bindingSource1;
        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
        private Button btnClassInfo;
        private Button btnEnrol;
        private Button btnTProfile;
    }
}