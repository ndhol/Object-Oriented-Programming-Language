﻿namespace IOOP_Assignment
{
    partial class AdminHome
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpTutor = new System.Windows.Forms.GroupBox();
            this.btndeletetutor = new System.Windows.Forms.Button();
            this.btnAssign = new System.Windows.Forms.Button();
            this.grpReceptionist = new System.Windows.Forms.GroupBox();
            this.btndeletereceptionist = new System.Windows.Forms.Button();
            this.btnReceptionist = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnIncome = new System.Windows.Forms.Button();
            this.btnProfile = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.grpTutor.SuspendLayout();
            this.grpReceptionist.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpTutor
            // 
            this.grpTutor.Controls.Add(this.btndeletetutor);
            this.grpTutor.Controls.Add(this.btnAssign);
            this.grpTutor.Location = new System.Drawing.Point(53, 432);
            this.grpTutor.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.grpTutor.Name = "grpTutor";
            this.grpTutor.Padding = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.grpTutor.Size = new System.Drawing.Size(437, 169);
            this.grpTutor.TabIndex = 0;
            this.grpTutor.TabStop = false;
            this.grpTutor.Text = "Tutor";
            // 
            // btndeletetutor
            // 
            this.btndeletetutor.Location = new System.Drawing.Point(35, 119);
            this.btndeletetutor.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.btndeletetutor.Name = "btndeletetutor";
            this.btndeletetutor.Size = new System.Drawing.Size(371, 39);
            this.btndeletetutor.TabIndex = 1;
            this.btndeletetutor.Text = "Delete Tutor";
            this.btndeletetutor.UseVisualStyleBackColor = true;
            this.btndeletetutor.Click += new System.EventHandler(this.btndeletetutor_Click);
            // 
            // btnAssign
            // 
            this.btnAssign.Location = new System.Drawing.Point(31, 50);
            this.btnAssign.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.btnAssign.Name = "btnAssign";
            this.btnAssign.Size = new System.Drawing.Size(375, 39);
            this.btnAssign.TabIndex = 0;
            this.btnAssign.Text = "Register & Assign Tutor";
            this.btnAssign.UseVisualStyleBackColor = true;
            this.btnAssign.Click += new System.EventHandler(this.btnAssign_Click);
            // 
            // grpReceptionist
            // 
            this.grpReceptionist.Controls.Add(this.btndeletereceptionist);
            this.grpReceptionist.Controls.Add(this.btnReceptionist);
            this.grpReceptionist.Location = new System.Drawing.Point(435, 157);
            this.grpReceptionist.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.grpReceptionist.Name = "grpReceptionist";
            this.grpReceptionist.Padding = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.grpReceptionist.Size = new System.Drawing.Size(437, 204);
            this.grpReceptionist.TabIndex = 1;
            this.grpReceptionist.TabStop = false;
            this.grpReceptionist.Text = "Receptionist";
            // 
            // btndeletereceptionist
            // 
            this.btndeletereceptionist.Location = new System.Drawing.Point(54, 105);
            this.btndeletereceptionist.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.btndeletereceptionist.Name = "btndeletereceptionist";
            this.btndeletereceptionist.Size = new System.Drawing.Size(311, 39);
            this.btndeletereceptionist.TabIndex = 1;
            this.btndeletereceptionist.Text = "Delete Receptionist";
            this.btndeletereceptionist.UseVisualStyleBackColor = true;
            this.btndeletereceptionist.Click += new System.EventHandler(this.btndeletereceptionist_Click);
            // 
            // btnReceptionist
            // 
            this.btnReceptionist.Location = new System.Drawing.Point(54, 45);
            this.btnReceptionist.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.btnReceptionist.Name = "btnReceptionist";
            this.btnReceptionist.Size = new System.Drawing.Size(311, 39);
            this.btnReceptionist.TabIndex = 0;
            this.btnReceptionist.Text = "Register Receptionist";
            this.btnReceptionist.UseVisualStyleBackColor = true;
            this.btnReceptionist.Click += new System.EventHandler(this.btnReceptionist_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnIncome);
            this.groupBox1.Location = new System.Drawing.Point(866, 432);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.groupBox1.Size = new System.Drawing.Size(384, 169);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            // 
            // btnIncome
            // 
            this.btnIncome.Location = new System.Drawing.Point(44, 78);
            this.btnIncome.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.btnIncome.Name = "btnIncome";
            this.btnIncome.Size = new System.Drawing.Size(286, 39);
            this.btnIncome.TabIndex = 0;
            this.btnIncome.Text = "Monthly Income";
            this.btnIncome.UseVisualStyleBackColor = true;
            this.btnIncome.Click += new System.EventHandler(this.btnIncome_Click);
            // 
            // btnProfile
            // 
            this.btnProfile.Location = new System.Drawing.Point(587, 496);
            this.btnProfile.Name = "btnProfile";
            this.btnProfile.Size = new System.Drawing.Size(161, 39);
            this.btnProfile.TabIndex = 3;
            this.btnProfile.Text = "Profile";
            this.btnProfile.UseVisualStyleBackColor = true;
            this.btnProfile.Click += new System.EventHandler(this.btnProfile_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Rockwell", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(477, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(336, 59);
            this.label1.TabIndex = 4;
            this.label1.Text = "Admin Home";
            // 
            // AdminHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 27F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(1274, 829);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnProfile);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.grpReceptionist);
            this.Controls.Add(this.grpTutor);
            this.Font = new System.Drawing.Font("Rockwell", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.Name = "AdminHome";
            this.Text = "FormHome";
            this.grpTutor.ResumeLayout(false);
            this.grpReceptionist.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private GroupBox grpTutor;
        private Button btndeletetutor;
        private Button btnAssign;
        private GroupBox grpReceptionist;
        private Button btndeletereceptionist;
        private Button btnReceptionist;
        private GroupBox groupBox1;
        private Button btnIncome;
        private Button btnProfile;
        private Label label1;
    }
}