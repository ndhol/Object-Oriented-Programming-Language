namespace IOOP_Assignment
{
    public partial class AdminHome : Form
    {
        private string name;
        private string role;
        public AdminHome(string name)
        {
            InitializeComponent();
            this.name = name;
            role = "admin";
        }

        private void btnReceptionist_Click(object sender, EventArgs e)
        {
            FormRegisterReceptionist objl=new FormRegisterReceptionist();
            objl.ShowDialog();
        }

        private void btndeletereceptionist_Click(object sender, EventArgs e)
        {
            FormDelRecep objl=new FormDelRecep();
            objl.ShowDialog();
        }

        private void btndeletetutor_Click(object sender, EventArgs e)
        {
            FormDeleteTutor objl=new FormDeleteTutor();
            objl.ShowDialog();
        }

        private void btnAssign_Click(object sender, EventArgs e)
        {
            FormRegisterTutor objl= new FormRegisterTutor();
            objl.ShowDialog();
        }

        private void btnIncome_Click(object sender, EventArgs e)
        {
            Income obj1=new Income(name);
            obj1.ShowDialog();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Update obj1=new Update();
            obj1.ShowDialog();
        }

        private void btnProfile_Click(object sender, EventArgs e)
        {
            EditProfile frm = new EditProfile(name);
            frm.ShowDialog();
        }
    }
}