﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment
{
    public partial class FormRegisterReceptionist : Form
    {
        public FormRegisterReceptionist()
        {
            InitializeComponent();
        }

        private void btnRegisterRecep_Click(object sender, EventArgs e)
        {
            Admin obj1 = new Admin(txtName.Text,txtIC.Text,txtAddress.Text,txtContact.Text,txtEmail.Text);
            MessageBox.Show(obj1.addRecep());
        }
    }
}
