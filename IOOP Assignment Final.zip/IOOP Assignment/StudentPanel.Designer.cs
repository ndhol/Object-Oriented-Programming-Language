﻿namespace IOOP_Assignment
{
    partial class frm_StudentPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pic_ProfilePic = new System.Windows.Forms.PictureBox();
            this.lbl_Name = new System.Windows.Forms.Label();
            this.btn_EditProfile = new System.Windows.Forms.Button();
            this.TimeSchedule = new System.Windows.Forms.ListBox();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_Send = new System.Windows.Forms.Button();
            this.lbl_Request = new System.Windows.Forms.Label();
            this.lbl_Month = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblContactNumber = new System.Windows.Forms.Label();
            this.lblAddress = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pic_ProfilePic)).BeginInit();
            this.SuspendLayout();
            // 
            // pic_ProfilePic
            // 
            this.pic_ProfilePic.Location = new System.Drawing.Point(19, 19);
            this.pic_ProfilePic.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.pic_ProfilePic.Name = "pic_ProfilePic";
            this.pic_ProfilePic.Size = new System.Drawing.Size(297, 316);
            this.pic_ProfilePic.TabIndex = 0;
            this.pic_ProfilePic.TabStop = false;
            // 
            // lbl_Name
            // 
            this.lbl_Name.AutoSize = true;
            this.lbl_Name.Location = new System.Drawing.Point(362, 68);
            this.lbl_Name.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lbl_Name.Name = "lbl_Name";
            this.lbl_Name.Size = new System.Drawing.Size(78, 32);
            this.lbl_Name.TabIndex = 2;
            this.lbl_Name.Text = "Name";
            // 
            // btn_EditProfile
            // 
            this.btn_EditProfile.Location = new System.Drawing.Point(362, 256);
            this.btn_EditProfile.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.btn_EditProfile.Name = "btn_EditProfile";
            this.btn_EditProfile.Size = new System.Drawing.Size(152, 47);
            this.btn_EditProfile.TabIndex = 4;
            this.btn_EditProfile.Text = "Edit Profile";
            this.btn_EditProfile.UseVisualStyleBackColor = true;
            this.btn_EditProfile.Click += new System.EventHandler(this.btn_EditProfile_Click_1);
            // 
            // TimeSchedule
            // 
            this.TimeSchedule.FormattingEnabled = true;
            this.TimeSchedule.ItemHeight = 32;
            this.TimeSchedule.Location = new System.Drawing.Point(43, 363);
            this.TimeSchedule.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.TimeSchedule.Name = "TimeSchedule";
            this.TimeSchedule.Size = new System.Drawing.Size(1217, 324);
            this.TimeSchedule.TabIndex = 5;
            this.TimeSchedule.SelectedIndexChanged += new System.EventHandler(this.TimeSchedule_SelectedIndexChanged_1);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(1029, 723);
            this.btn_delete.Margin = new System.Windows.Forms.Padding(6);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(139, 49);
            this.btn_delete.TabIndex = 6;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            // 
            // btn_Send
            // 
            this.btn_Send.Location = new System.Drawing.Point(878, 723);
            this.btn_Send.Margin = new System.Windows.Forms.Padding(6);
            this.btn_Send.Name = "btn_Send";
            this.btn_Send.Size = new System.Drawing.Size(139, 49);
            this.btn_Send.TabIndex = 7;
            this.btn_Send.Text = "Send";
            this.btn_Send.UseVisualStyleBackColor = true;
            this.btn_Send.Click += new System.EventHandler(this.btn_Send_Click_1);
            // 
            // lbl_Request
            // 
            this.lbl_Request.AutoSize = true;
            this.lbl_Request.Location = new System.Drawing.Point(399, 732);
            this.lbl_Request.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lbl_Request.Name = "lbl_Request";
            this.lbl_Request.Size = new System.Drawing.Size(469, 32);
            this.lbl_Request.TabIndex = 8;
            this.lbl_Request.Text = "To request change subject/ delete request:";
            // 
            // lbl_Month
            // 
            this.lbl_Month.AutoSize = true;
            this.lbl_Month.Location = new System.Drawing.Point(362, 122);
            this.lbl_Month.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lbl_Month.Name = "lbl_Month";
            this.lbl_Month.Size = new System.Drawing.Size(86, 32);
            this.lbl_Month.TabIndex = 9;
            this.lbl_Month.Text = "Month";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(362, 173);
            this.lblEmail.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(71, 32);
            this.lblEmail.TabIndex = 10;
            this.lblEmail.Text = "Email";
            // 
            // lblContactNumber
            // 
            this.lblContactNumber.AutoSize = true;
            this.lblContactNumber.Location = new System.Drawing.Point(570, 68);
            this.lblContactNumber.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblContactNumber.Name = "lblContactNumber";
            this.lblContactNumber.Size = new System.Drawing.Size(184, 32);
            this.lblContactNumber.TabIndex = 11;
            this.lblContactNumber.Text = "ContactNumber";
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new System.Drawing.Point(570, 122);
            this.lblAddress.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(98, 32);
            this.lblAddress.TabIndex = 12;
            this.lblAddress.Text = "Address";
            // 
            // frm_StudentPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1300, 798);
            this.Controls.Add(this.lblAddress);
            this.Controls.Add(this.lblContactNumber);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.lbl_Month);
            this.Controls.Add(this.lbl_Request);
            this.Controls.Add(this.btn_Send);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.TimeSchedule);
            this.Controls.Add(this.btn_EditProfile);
            this.Controls.Add(this.lbl_Name);
            this.Controls.Add(this.pic_ProfilePic);
            this.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.Name = "frm_StudentPanel";
            this.Text = "StudentPanel";
            this.Load += new System.EventHandler(this.frm_StudentPanel_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.pic_ProfilePic)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox pic_ProfilePic;
        private Label lbl_Name;
        private Button btn_EditProfile;
        private ListBox TimeSchedule;
        private Button btn_delete;
        private Button btn_Send;
        private Label lbl_Request;
        private Label lbl_Month;
        private Label lblEmail;
        private Label lblContactNumber;
        private Label lblAddress;
    }
}