﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace IOOP_Assignment
{
    public partial class FrmClassInfo : Form
    {
        public static string name;

        bool hidden = true;

        public FrmClassInfo(string n)
        {
            InitializeComponent();
            name = n;

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

       
        private void btnCharge_Click(object sender, EventArgs e)
        {
            if (hidden==true)
            {
                hidden = false;
                txtCharge.Show();
                btnConfirm.Show();
                btnCharge.Text="Cancel";
            }
            else
            {
                hidden = true;
                txtCharge.Hide();
                btnConfirm.Hide();
                btnCharge.Text = "Edit";
            }
        }

        private void btnSch_Click(object sender, EventArgs e)
        {
            try
            {
                int l = int.Parse(cmbLevel.Text);
                FrmEditSch obj3 = new FrmEditSch(name, cmbLevel.Text, lblCharge.Text, lblSub.Text);
                obj3.Show();
            }

            catch 
            {
                MessageBox.Show("Select Level to add classtime to");
            }
                
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            FrmTutorHome frm=new FrmTutorHome(name);
            frm.Show();
            this.Hide();
        }

        private void FrmClassInfo_Load(object sender, EventArgs e)
        {
            txtCharge.Hide();
            btnConfirm.Hide();
            ArrayList level = new ArrayList();

            level = Class.viewLevel(name);
            foreach (var item in level)
            {
                cmbLevel.Items.Add(item);
            }
            
        }



        private void cmbLevel_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbSch.Text = "";
            cmbTime.Text = "";
            cmbSch.Items.Clear();
            
            string a = cmbLevel.Text.ToString();
            Class subject = new Class(name);
            string sub= subject.viewSub(name, a);
            string charge = subject.viewCharge(name, a);
            lblSub.Text=sub;
            lblCharge.Text = charge;
            
            
            ArrayList day = new ArrayList();
        
            day = Class.viewDay(name, a, sub);

            foreach (var item in day)
            {
                cmbSch.Items.Add(item);
            }
            

            
            



        }

        private void lblSub_Click(object sender, EventArgs e)
        {

        }

        private void cmbSch_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbTime.Items.Clear();
            string day = cmbSch.Text.ToString();
            
            string level = cmbLevel.Text.ToString();
            string sub = lblSub.Text;
            ArrayList time = new ArrayList();
            time = Class.viewTime(name,level,sub,day);
            foreach (var item in time)
            {
                cmbTime.Items.Add(item);
            }

        }

        private void lBSch_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void lblCharge_Click(object sender, EventArgs e)
        {

        }
        
        private void txtCharge_TextChanged(object sender, EventArgs e)
        {
            string newCharge = txtCharge.Text;
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            string sub=lblSub.Text; 
            string level = cmbLevel.Text;
            string newCharge = txtCharge.Text;
            try
            {   int charge=int.Parse(newCharge);
                Class change = new Class(name);
                string status = change.updateCharge(sub, level, newCharge);
                MessageBox.Show(status);
                btnConfirm.Hide();
                txtCharge.Hide();
                btnCharge.Text = "Edit";
            }
            catch
            {
                MessageBox.Show("Invalid data entered");
            }
           
            cmbLevel_SelectedIndexChanged(sender, e);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string d = cmbSch.Text;
            string t= cmbTime.Text;
            Class deletion= new Class(name);
            string status = deletion.deleteTime(d,t);
            MessageBox.Show(status);
            cmbLevel_SelectedIndexChanged(sender, e);
        }
    }
}
