﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;


namespace IOOP_Assignment
{
    internal class Class
    {
        private string tutor;
        private string day;
        private string time;
        private string charge;
        private string level;
        private string sub;
        private string newCharge;
        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

        public string Tutor { get => tutor; set => tutor = value; }
        public string Day { get => day; set => day = value; }
        public string Time { get => time; set => time = value; }
        public string Charge { get => charge; set => charge = value; }
        public string Level { get => level; set => level = value; }
        public string Sub { get => sub; set => sub = value; }

        public Class(string n)
        { 
            tutor=n;
        }
        
        public Class(string t,string l, string s, string d)
        {
            tutor = t;
            level = l;
            sub = s;
            day = d;
        }

        public Class(string n, string l, string s, string d,string t)
        {
            tutor = n;
            level = l;
            sub = s;
            day = d;
            time = t;
            

        }

        public Class(string t, string l, string s)
        {
            tutor = t;
            level = l;
            sub = s;
           
        }

       
        
        public static ArrayList viewLevel(string tutor)
        {
            
            ArrayList nm = new ArrayList();
            con.Open();
            SqlCommand cmd = new SqlCommand("select distinct level from subject where tutor= '" + tutor + "'" , con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                nm.Add(rd.GetString(0));
            }
            con.Close();
            return nm;

        }

        public string viewSub(string tutor,string level)
        {
            con.Open();
            SqlCommand cmd= new SqlCommand("select subject from subject where tutor= '" + tutor + "' and level= '" +level+ "'", con);
            string subject = cmd.ExecuteScalar().ToString();
            con.Close();
            return subject;

        }

        public string viewCharge(string tutor, string level)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select charge from subject where tutor= '" + tutor + "' and level= '" + level + "'", con);
            string charge = cmd.ExecuteScalar().ToString();
            con.Close();
            return charge;

        }

        public static ArrayList viewDay(string tutor,string level,string sub)
        {
            
            ArrayList day = new ArrayList();
            con.Open();
            SqlCommand cmd = new SqlCommand("select distinct day from classInfo where tutor = '" + tutor + "' and level = '" + level + "' and subject= '"+sub+"'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
               day.Add(rd.GetString(0));
            }
            con.Close();
            return day;

        }

        public static ArrayList viewTime(string tutor, string level,string sub, string day)
        {
            ArrayList time = new ArrayList();
            con.Open();
            SqlCommand cmd = new SqlCommand("select time from classInfo where tutor = '" + tutor + "' and level = '" + level + "' and subject= '" + sub + "' and day= '"+ day + "'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                time.Add(rd.GetString(0));
            }
            con.Close();
            return time;
        }

        public static ArrayList viewStudent(string tutor,string level)
        {
            ArrayList nm = new ArrayList();
            con.Open();
            SqlCommand cmd = new SqlCommand("select distinct name from enrolement where tutor = '" + tutor + "' and level = '" + level + "'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                nm.Add(rd.GetString(0));
            }
            con.Close();
            return nm;

        }


        public static ArrayList allDayTime()
        {
            ArrayList time = new ArrayList();
            con.Open();
            SqlCommand cmd = new SqlCommand("select day,time from classInfo order by day ",con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                time.Add(rd.GetString(0)+ "\t"+ rd.GetString(1));
                
            }
            con.Close();
            return time;
            

        }

        public string updateCharge(string sub, string level, string newCharge)
        {
            string status;
            con.Open();
            SqlCommand cmd = new SqlCommand("update subject set charge = '" + newCharge + "' where subject= '" + sub + "' and level= '" + level + "'", con);
            SqlCommand cmd2 = new SqlCommand("update enrolement set payment = '" + newCharge + "' where subject= '" + sub + "' and level= '" + level + "'", con);
            cmd.ExecuteNonQuery();
            int i = cmd.ExecuteNonQuery();
            if (i != 0)
            {
                status = "Update Successfully";
            }
            else
            {
                status = "Unable to update";
            }

            con.Close();
            return status;


        }

        public string addTime(string tutor,string level,string sub,string day,string time)
        {
            string status;
            con.Open();
            SqlCommand cmd1 = new SqlCommand("select count (*) subject from classInfo where tutor= '" + tutor + "' and day='" + day + "' and time= '" + time + "'", con);
            int count= Convert.ToInt32(cmd1.ExecuteScalar().ToString());
            if (count>0)
            {
                status = tutor + " has another class at this time";
            }
            else
            {
                SqlCommand cmd = new SqlCommand("insert into classInfo (tutor,level,subject,day,time) values(@tutor,@level,@subject,@day,@time)", con);
                cmd.Parameters.AddWithValue("@tutor", tutor);
                cmd.Parameters.AddWithValue("@level", level);
                cmd.Parameters.AddWithValue("@subject", sub);
                cmd.Parameters.AddWithValue("@day", day);
                cmd.Parameters.AddWithValue("@time", time);
                
                
                status = "Class successfully added.";
            }
           
            con.Close();
            return status;
            
            
        }

        public string deleteTime(string day, string time)
        {
            string status;
            con.Open();
            SqlCommand cmd = new SqlCommand("delete from classInfo where day= '"+ day + "' and time= '" + time + "'", con);
            cmd.ExecuteReader();
            con.Close();
            con.Open();
            SqlCommand cmd1 = new SqlCommand("select count (*) from classInfo where day= '" + day + "' and time= '" + time + "'", con);
            int count = Convert.ToInt32(cmd1.ExecuteScalar().ToString());
            if (count>0 )
            {
                status = "Deletion unsuccessful";
            }
            else
            {
                status = "Deletion succesful";
            }
            con.Close();
            return status;

            

        }






    }
}
