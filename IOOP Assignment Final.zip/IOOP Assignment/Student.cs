﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace IOOP_Assignment
{
    internal class Student
    {
        private string Email;
        private string Address;
        private string Name;
        private string PhoneNumber;
        private ArrayList Level;
        private ArrayList Subject;
        private string Month;
        private ArrayList Tutor;
        private string Day;
        private ArrayList TimeSchedule;
        private ArrayList day;
        private ArrayList time;
        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

        public string Email1 { get => Email; set => Email = value; }
        public string PhoneNumber1 { get => PhoneNumber; set => PhoneNumber = value; }
        public string Address1 { get => Address; set => Address = value; }
        public string Name1 { get => Name; set => Name = value; }
        
        public string Month1 { get => Month; set => Month = value; }
        
        
        public ArrayList Tutor1 { get => Tutor; set => Tutor = value; }
        public ArrayList TimeSchedule1 { get => TimeSchedule; set => TimeSchedule = value; }
        public ArrayList Subject2 { get => Subject; set => Subject = value; }
        public ArrayList Level1 { get => Level; set => Level = value; }

        public Student(string n)
        {
            Name = n;
        }



        public string updateProfile(string em, string add, string phoneNum)
        {
            string status;
            con.Open();

            Email = em;
            PhoneNumber = phoneNum;
            Address = add;

            SqlCommand cmd = new SqlCommand("update students set email='" + Email + "',contact='" + PhoneNumber + "',address='" + Address + "'", con);
            int i = cmd.ExecuteNonQuery();
            if (i != 0)
                status = "Update Successfully.";
            else
                status = "Unable to update";
            con.Close();
            return status;
        }
        public static void timeschedule(Student o1)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("'Select level, subject from enrolement where StudentName='" + o1.Name1 + "'", con);


        }

        public string addRequest(string r)
        {
            string request = r;
            string status;
            con.Open();
            SqlCommand cmd1 = new SqlCommand("select count (*) from requests where name= @name", con);
            cmd1.Parameters.AddWithValue("@name", Name);
            int count = Convert.ToInt32(cmd1.ExecuteScalar().ToString());
            if (count > 0)
            {
                status = "Only 1 request at a time. Wait for request to be processed or delete and make a new one.";
                con.Close();
                return status;
            }
            
            SqlCommand cmd = new SqlCommand("insert into requests(name,request)values(@name,@r)", con);
            cmd.Parameters.AddWithValue("@name", Name);
            cmd.Parameters.AddWithValue("@r", request);
            int i = cmd.ExecuteNonQuery();
            if (i != 0)
                status = "Request Submitted.";
            else
                status = "Unable to send request.";
            con.Close();
            return status;

        }
        public static void viewProfile(Student o1)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select name, month, email, contact, address from students where name='" + o1.Name1 + "'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                o1.Name1 = rd.GetString(0);
                o1.Month1 = rd.GetString(1);
                o1.Email1 = rd.GetString(2);
                o1.PhoneNumber1 = rd.GetString(3);
                o1.Address1 = rd.GetString(4);
            }
            con.Close();
        }
        
        public static void viewsubjecttimeschedule(Student s1)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select level, subject, tutor from enrolement where name= '" + s1.Name1 + "'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                s1.Level1.Add(rd.GetString(0));
                s1.Subject2.Add(rd.GetString(1));
                s1.Tutor1.Add(rd.GetString(2));
            }
            
            con.Close();
        }

        public static ArrayList viewSch(Student s1)
        {
            con.Open();
            ArrayList time= new ArrayList();
            SqlCommand cmd = new SqlCommand("Select classInfo.subject,classInfo.day,classInfo.time from classInfo Inner Join enrolement on classInfo.level=enrolement.level and classInfo.subject=enrolement.subject where enrolement.name=@name", con);
            cmd.Parameters.AddWithValue("@name", s1.Name1);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                //s1.Level1= rd.GetString(0);
                time.Add(rd.GetString(0) + "\t\t" + rd.GetString(1) + "\t\t" + rd.GetString(2) );
            }
            con.Close();
            return time;
        }
      
        






















    }

    
   
}
