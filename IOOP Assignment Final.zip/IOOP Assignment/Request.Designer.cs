﻿namespace IOOP_Assignment
{
    partial class frm_Request
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Subject = new System.Windows.Forms.Label();
            this.btn_Send = new System.Windows.Forms.Button();
            this.btn_Return = new System.Windows.Forms.Button();
            this.txtr = new System.Windows.Forms.RichTextBox();
            this.btndelete = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_Subject
            // 
            this.lbl_Subject.AutoSize = true;
            this.lbl_Subject.BackColor = System.Drawing.Color.Sienna;
            this.lbl_Subject.Font = new System.Drawing.Font("Rockwell", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_Subject.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_Subject.Location = new System.Drawing.Point(253, 52);
            this.lbl_Subject.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lbl_Subject.Name = "lbl_Subject";
            this.lbl_Subject.Size = new System.Drawing.Size(241, 59);
            this.lbl_Subject.TabIndex = 2;
            this.lbl_Subject.Text = "Requests";
            // 
            // btn_Send
            // 
            this.btn_Send.Location = new System.Drawing.Point(137, 586);
            this.btn_Send.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.btn_Send.Name = "btn_Send";
            this.btn_Send.Size = new System.Drawing.Size(150, 41);
            this.btn_Send.TabIndex = 3;
            this.btn_Send.Text = "Send";
            this.btn_Send.UseVisualStyleBackColor = true;
            this.btn_Send.Click += new System.EventHandler(this.btn_Send_Click);
            // 
            // btn_Return
            // 
            this.btn_Return.Location = new System.Drawing.Point(585, 719);
            this.btn_Return.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.btn_Return.Name = "btn_Return";
            this.btn_Return.Size = new System.Drawing.Size(150, 41);
            this.btn_Return.TabIndex = 4;
            this.btn_Return.Text = "Return";
            this.btn_Return.UseVisualStyleBackColor = true;
            this.btn_Return.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtr
            // 
            this.txtr.Location = new System.Drawing.Point(137, 150);
            this.txtr.Name = "txtr";
            this.txtr.Size = new System.Drawing.Size(488, 163);
            this.txtr.TabIndex = 5;
            this.txtr.Text = "";
            // 
            // btndelete
            // 
            this.btndelete.Location = new System.Drawing.Point(475, 586);
            this.btndelete.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(150, 41);
            this.btndelete.TabIndex = 6;
            this.btndelete.Text = "Delete";
            this.btndelete.UseVisualStyleBackColor = true;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // frm_Request
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 27F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Peru;
            this.ClientSize = new System.Drawing.Size(772, 786);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.txtr);
            this.Controls.Add(this.btn_Return);
            this.Controls.Add(this.btn_Send);
            this.Controls.Add(this.lbl_Subject);
            this.Font = new System.Drawing.Font("Rockwell", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Name = "frm_Request";
            this.Text = "Request";
            this.Load += new System.EventHandler(this.frm_Request_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Label lbl_Subject;
        private Button btn_Send;
        private Button btn_Return;
        private RichTextBox txtr;
        private Button btndelete;
    }
}