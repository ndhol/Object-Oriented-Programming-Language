﻿namespace IOOP_Assignment
{
    partial class FormDelRecep
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblDelRecep = new System.Windows.Forms.Label();
            this.lblDelName = new System.Windows.Forms.Label();
            this.btnDelRecep = new System.Windows.Forms.Button();
            this.lstRecepName = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // lblDelRecep
            // 
            this.lblDelRecep.AutoSize = true;
            this.lblDelRecep.BackColor = System.Drawing.Color.SeaGreen;
            this.lblDelRecep.Font = new System.Drawing.Font("Rockwell", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDelRecep.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblDelRecep.Location = new System.Drawing.Point(407, 78);
            this.lblDelRecep.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblDelRecep.Name = "lblDelRecep";
            this.lblDelRecep.Size = new System.Drawing.Size(491, 59);
            this.lblDelRecep.TabIndex = 0;
            this.lblDelRecep.Text = "Delete Receptionist";
            // 
            // lblDelName
            // 
            this.lblDelName.AutoSize = true;
            this.lblDelName.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblDelName.Location = new System.Drawing.Point(318, 205);
            this.lblDelName.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblDelName.Name = "lblDelName";
            this.lblDelName.Size = new System.Drawing.Size(101, 33);
            this.lblDelName.TabIndex = 1;
            this.lblDelName.Text = "Name : ";
            // 
            // btnDelRecep
            // 
            this.btnDelRecep.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnDelRecep.Location = new System.Drawing.Point(600, 617);
            this.btnDelRecep.Margin = new System.Windows.Forms.Padding(5);
            this.btnDelRecep.Name = "btnDelRecep";
            this.btnDelRecep.Size = new System.Drawing.Size(153, 46);
            this.btnDelRecep.TabIndex = 2;
            this.btnDelRecep.Text = "Delete";
            this.btnDelRecep.UseVisualStyleBackColor = true;
            this.btnDelRecep.Click += new System.EventHandler(this.btnDelRecep_Click);
            // 
            // lstRecepName
            // 
            this.lstRecepName.FormattingEnabled = true;
            this.lstRecepName.ItemHeight = 32;
            this.lstRecepName.Location = new System.Drawing.Point(494, 205);
            this.lstRecepName.Margin = new System.Windows.Forms.Padding(5);
            this.lstRecepName.Name = "lstRecepName";
            this.lstRecepName.Size = new System.Drawing.Size(358, 292);
            this.lstRecepName.TabIndex = 3;
            // 
            // FormDelRecep
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.ClientSize = new System.Drawing.Size(1300, 720);
            this.Controls.Add(this.lstRecepName);
            this.Controls.Add(this.btnDelRecep);
            this.Controls.Add(this.lblDelName);
            this.Controls.Add(this.lblDelRecep);
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "FormDelRecep";
            this.Text = "FormDelRecep";
            this.Load += new System.EventHandler(this.FormDelRecep_Load_1);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblDelRecep;
        private Label lblDelName;
        private Button btnDelRecep;
        private ListBox lstRecepName;
    }
}