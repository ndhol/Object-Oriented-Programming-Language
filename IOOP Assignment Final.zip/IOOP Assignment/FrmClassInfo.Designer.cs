﻿namespace IOOP_Assignment
{
    partial class FrmClassInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmClassInfo));
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblS = new System.Windows.Forms.Label();
            this.lblL = new System.Windows.Forms.Label();
            this.lblC = new System.Windows.Forms.Label();
            this.lblSch = new System.Windows.Forms.Label();
            this.lblSub = new System.Windows.Forms.Label();
            this.cmbLevel = new System.Windows.Forms.ComboBox();
            this.lblCharge = new System.Windows.Forms.Label();
            this.btnCharge = new System.Windows.Forms.Button();
            this.btnSch = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.cmbSch = new System.Windows.Forms.ComboBox();
            this.txtCharge = new System.Windows.Forms.TextBox();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.cmbTime = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.BackColor = System.Drawing.Color.IndianRed;
            this.lblTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTitle.Font = new System.Drawing.Font("Rockwell", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblTitle.Location = new System.Drawing.Point(359, 66);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(605, 79);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Class Information";
            // 
            // lblS
            // 
            this.lblS.AutoSize = true;
            this.lblS.Location = new System.Drawing.Point(145, 287);
            this.lblS.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblS.Name = "lblS";
            this.lblS.Size = new System.Drawing.Size(227, 36);
            this.lblS.TabIndex = 1;
            this.lblS.Text = "Subject Name:";
            // 
            // lblL
            // 
            this.lblL.AutoSize = true;
            this.lblL.Location = new System.Drawing.Point(718, 290);
            this.lblL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblL.Name = "lblL";
            this.lblL.Size = new System.Drawing.Size(102, 36);
            this.lblL.TabIndex = 2;
            this.lblL.Text = "Level:";
            this.lblL.Click += new System.EventHandler(this.label2_Click);
            // 
            // lblC
            // 
            this.lblC.AutoSize = true;
            this.lblC.Location = new System.Drawing.Point(155, 397);
            this.lblC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblC.Name = "lblC";
            this.lblC.Size = new System.Drawing.Size(149, 36);
            this.lblC.TabIndex = 3;
            this.lblC.Text = "Charges:";
            // 
            // lblSch
            // 
            this.lblSch.AutoSize = true;
            this.lblSch.Location = new System.Drawing.Point(145, 510);
            this.lblSch.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSch.Name = "lblSch";
            this.lblSch.Size = new System.Drawing.Size(245, 36);
            this.lblSch.TabIndex = 4;
            this.lblSch.Text = "Class Schedule:";
            // 
            // lblSub
            // 
            this.lblSub.AutoSize = true;
            this.lblSub.BackColor = System.Drawing.Color.IndianRed;
            this.lblSub.Location = new System.Drawing.Point(485, 287);
            this.lblSub.Name = "lblSub";
            this.lblSub.Size = new System.Drawing.Size(0, 36);
            this.lblSub.TabIndex = 5;
            this.lblSub.Click += new System.EventHandler(this.lblSub_Click);
            // 
            // cmbLevel
            // 
            this.cmbLevel.FormattingEnabled = true;
            this.cmbLevel.Location = new System.Drawing.Point(930, 287);
            this.cmbLevel.Name = "cmbLevel";
            this.cmbLevel.Size = new System.Drawing.Size(242, 44);
            this.cmbLevel.TabIndex = 6;
            this.cmbLevel.SelectedIndexChanged += new System.EventHandler(this.cmbLevel_SelectedIndexChanged);
            // 
            // lblCharge
            // 
            this.lblCharge.AutoSize = true;
            this.lblCharge.BackColor = System.Drawing.Color.IndianRed;
            this.lblCharge.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCharge.Location = new System.Drawing.Point(504, 397);
            this.lblCharge.Name = "lblCharge";
            this.lblCharge.Size = new System.Drawing.Size(2, 38);
            this.lblCharge.TabIndex = 7;
            // 
            // btnCharge
            // 
            this.btnCharge.BackColor = System.Drawing.Color.Brown;
            this.btnCharge.Location = new System.Drawing.Point(930, 396);
            this.btnCharge.Name = "btnCharge";
            this.btnCharge.Size = new System.Drawing.Size(150, 46);
            this.btnCharge.TabIndex = 9;
            this.btnCharge.Text = "Edit";
            this.btnCharge.UseVisualStyleBackColor = false;
            this.btnCharge.Click += new System.EventHandler(this.btnCharge_Click);
            // 
            // btnSch
            // 
            this.btnSch.BackColor = System.Drawing.Color.Brown;
            this.btnSch.Location = new System.Drawing.Point(802, 654);
            this.btnSch.Name = "btnSch";
            this.btnSch.Size = new System.Drawing.Size(150, 46);
            this.btnSch.TabIndex = 10;
            this.btnSch.Text = "Add";
            this.btnSch.UseVisualStyleBackColor = false;
            this.btnSch.Click += new System.EventHandler(this.btnSch_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1089, 59);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(109, 86);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // cmbSch
            // 
            this.cmbSch.FormattingEnabled = true;
            this.cmbSch.Location = new System.Drawing.Point(485, 512);
            this.cmbSch.Name = "cmbSch";
            this.cmbSch.Size = new System.Drawing.Size(218, 44);
            this.cmbSch.TabIndex = 8;
            this.cmbSch.SelectedIndexChanged += new System.EventHandler(this.cmbSch_SelectedIndexChanged);
            // 
            // txtCharge
            // 
            this.txtCharge.Location = new System.Drawing.Point(504, 398);
            this.txtCharge.Name = "txtCharge";
            this.txtCharge.Size = new System.Drawing.Size(109, 45);
            this.txtCharge.TabIndex = 15;
            this.txtCharge.TextChanged += new System.EventHandler(this.txtCharge_TextChanged);
            // 
            // btnConfirm
            // 
            this.btnConfirm.BackColor = System.Drawing.Color.Brown;
            this.btnConfirm.Location = new System.Drawing.Point(687, 395);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(150, 46);
            this.btnConfirm.TabIndex = 16;
            this.btnConfirm.Text = "Confirm";
            this.btnConfirm.UseVisualStyleBackColor = false;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Brown;
            this.button1.Location = new System.Drawing.Point(1037, 512);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(150, 46);
            this.button1.TabIndex = 17;
            this.button1.Text = "Delete";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // cmbTime
            // 
            this.cmbTime.FormattingEnabled = true;
            this.cmbTime.Location = new System.Drawing.Point(749, 510);
            this.cmbTime.Name = "cmbTime";
            this.cmbTime.Size = new System.Drawing.Size(254, 44);
            this.cmbTime.TabIndex = 18;
            // 
            // FrmClassInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(19F, 36F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(1274, 829);
            this.Controls.Add(this.cmbTime);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnConfirm);
            this.Controls.Add(this.txtCharge);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnSch);
            this.Controls.Add(this.btnCharge);
            this.Controls.Add(this.cmbSch);
            this.Controls.Add(this.lblCharge);
            this.Controls.Add(this.cmbLevel);
            this.Controls.Add(this.lblSub);
            this.Controls.Add(this.lblSch);
            this.Controls.Add(this.lblC);
            this.Controls.Add(this.lblL);
            this.Controls.Add(this.lblS);
            this.Controls.Add(this.lblTitle);
            this.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "FrmClassInfo";
            this.Text = "Class Information";
            this.Load += new System.EventHandler(this.FrmClassInfo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblTitle;
        private Label lblS;
        private Label lblL;
        private Label lblC;
        private Label lblSch;
        private Label lblSub;
        private ComboBox cmbLevel;
        private Label lblCharge;
        private Button btnCharge;
        private Button btnSch;
        private PictureBox pictureBox1;
        private ComboBox cmbSch;
        private TextBox txtCharge;
        private Button btnConfirm;
        private Button button1;
        private ComboBox cmbTime;
    }
}