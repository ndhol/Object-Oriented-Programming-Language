﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment
{
    public partial class FormRegisterTutor : Form
    {
        public FormRegisterTutor()
        {
            InitializeComponent();
        }

        private void btnAssignTutor_Click(object sender, EventArgs e)
        {
            FormAssign objl= new FormAssign();
            objl.ShowDialog();
        }

        private void btnRegisterTutor_Click(object sender, EventArgs e)
        {
            Admin obj1 = new Admin(txtName.Text, txtIC.Text, txtAddress.Text, txtContact.Text, txtEmail.Text);
            MessageBox.Show(obj1.addTutor());
        }
    }
}
