﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment
{
    public partial class FrmTutorHome : Form
    {
        public static string name;
        public FrmTutorHome(string n)
        {
            InitializeComponent();
            name = n;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void btnClassInfo_Click(object sender, EventArgs e)
        {
            FrmClassInfo obj1= new FrmClassInfo(name);
            obj1.ShowDialog();
            
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnEnrol_Click(object sender, EventArgs e)
        {
            FrmEnrol frm= new FrmEnrol(name);
            frm.ShowDialog();
        }

        private void btnTProfile_Click(object sender, EventArgs e)
        {
            EditProfile frm = new EditProfile(name);
            frm.ShowDialog();
        }

        private void FrmTutorHome_Load(object sender, EventArgs e)
        {
       
        }
    }
}
