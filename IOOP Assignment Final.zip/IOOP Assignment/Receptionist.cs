﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace IOOP_Assignment
{
    internal class Receptionist
    {
        private string studName;
        private string ic;
        private string email;
        private string phoneNum;
        private string address;
        private string level;
        private string enroll;
        private string subject1;
        private string subject2;
        private string subject3;
        private string pay;
        private ArrayList charge;
        
        public string Level { get => level; set => level = value; }
        public string Ic { get => ic; set => ic = value; }
        public string Email { get => email; set => email = value; }
        public string PhoneNum { get => phoneNum; set => phoneNum = value; }
        public string Address { get => address; set => address = value; }
        public string Enroll { get => enroll; set => enroll = value; }
        public string Subject1 { get => subject1; set => subject1 = value; }
        public string Subject2 { get => subject2; set => subject2 = value; }
        public string Subject3 { get => subject3; set => subject3 = value; }
        public string Pay { get => pay; set => pay = value; }

        public Receptionist()
        {
           
        }

        public Receptionist(string Name)
        {
            studName = Name;
        }

        public Receptionist (string Name, string IC, string Email, string PhoneNum, string Address, string Level, string Month)
        {
            studName = Name;
            ic = IC;
            email = Email;
            phoneNum = PhoneNum;
            address = Address;
            level = Level;
            enroll = Month;
        }

        public Receptionist (string Name, string Level, string s1, string s2, string s3)
        {
            studName = Name;
            level= Level;
            subject1 = s1;
            subject2 = s2;
            subject3 = s3;
            
        }

        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

        public string addStudent() 
        {
            string status;
            con.Open();
            SqlCommand cmd8 = new SqlCommand("select count (*)  from students where name= '" + studName + "'", con);
            int count = Convert.ToInt32(cmd8.ExecuteScalar().ToString());
            if (count > 0)
            {
                status = "Student already registered";
                con.Close();
                return status;
            }
            SqlCommand cmd = new SqlCommand("insert into students (name, IC, email, contact, address, month) values (@name, @ic, @em, @num, @add, @mon)", con);
            SqlCommand cmd2 = new SqlCommand("insert into users (username,password,role) values(@name,'678','student')", con);
            cmd.Parameters.AddWithValue("@name", studName);
            cmd2.Parameters.AddWithValue("@name", studName);
            cmd.Parameters.AddWithValue("@ic", ic);
            cmd.Parameters.AddWithValue("@em", Email);
            cmd.Parameters.AddWithValue("@num", phoneNum);
            cmd.Parameters.AddWithValue("@add", address);
            
            cmd.Parameters.AddWithValue("@mon", enroll);
            cmd2.ExecuteNonQuery();

            int i = cmd.ExecuteNonQuery();
            if (i != 0)
                status = "Registration successful.";
            else
                status = "unable to register,";
            con.Close();
            return status;


        }

       

        public string subject()
        {
            string status;
            string tutor1;
            string tutor2;
            string tutor3;
            string charge1;
            string charge2;
            string charge3;
            con.Open();
            SqlCommand cmd6 = new SqlCommand("select count (*)  from enrolement where name= '" + studName + "' and level='"+level+"' and subject= '" + subject1+"'",con);
            int count = Convert.ToInt32(cmd6.ExecuteScalar().ToString());
            if (count > 0)
            {
                status = "Already enrolled in class";
                con.Close();
                return status;
            }
            con.Close();
            ArrayList nm = new ArrayList();
            con.Open();
            
            SqlCommand cmd1 = new SqlCommand("select tutor,charge from subject where level='"+level+"' and subject= '"+subject1+"'", con);
            SqlDataReader rd = cmd1.ExecuteReader();
            while (rd.Read())
            {
                nm.Add(rd.GetString(0));//add element into arraylist
                nm.Add(rd.GetString(1));
            }
            
            tutor1 = (string)nm[0];
            charge1 = (string)nm[1];

            con.Close();
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into enrolement (name, level, subject,tutor,payment,status) values (@name, @level,@sub,@tutor,@charge,'unpaid')", con);
            cmd.Parameters.AddWithValue("@name", studName);
            cmd.Parameters.AddWithValue("@level", level);
            cmd.Parameters.AddWithValue("@sub", subject1);
            cmd.Parameters.AddWithValue("@tutor", tutor1);
            cmd.Parameters.AddWithValue("@charge", charge1);


            int i = cmd.ExecuteNonQuery();
            if (i != 0)
                status = "Subjects registered.";
            else
                status = "unable to register.";
            con.Close();

            if(subject2!=null)
            {
                con.Open();
                SqlCommand cmd7 = new SqlCommand("select count (*)  from enrolement where name= '" + studName + " and level='" + level + "' and subject= '" + subject2 + "'", con);
                count = Convert.ToInt32(cmd6.ExecuteScalar().ToString());
                if (count > 0)
                {
                    status = "Already enrolled in class";
                    con.Close();
                    return status;
                    
                }
                con.Close();
                nm.Clear();
                con.Open();
                SqlCommand cmd4 = new SqlCommand("select tutor, charge from subject where level='" + level + "' and subject= '" + subject2+ "'", con);
                SqlDataReader r = cmd4.ExecuteReader();
                while (r.Read())
                {
                    nm.Add(r.GetString(0));//add element into arraylist
                    nm.Add(r.GetString(1));
                }
                
                tutor2= (string)nm[0];
                charge2 = (string)nm[1];
                con.Close();
                con.Open();
                
                SqlCommand cmd2 = new SqlCommand("insert into enrolement (name, level, subject,tutor,payment,status) values (@name, @level,@sub,@tutor,@charge,'unpaid')", con);
                cmd2.Parameters.AddWithValue("@name", studName);
                cmd2.Parameters.AddWithValue("@level", level);
                cmd2.Parameters.AddWithValue("@sub", subject2);
                cmd2.Parameters.AddWithValue("@tutor", tutor2);
                cmd2.Parameters.AddWithValue("@charge", charge2);


                int j = cmd2.ExecuteNonQuery();
                if (j != 0)
                    status = "Subjects registered.";
                else
                    status = "unable to register.";
                con.Close();

            }
            else
            {
                return status;
            }
            
            if (subject3!=null)
            {
                con.Open();
                SqlCommand cmd8 = new SqlCommand("select count (*)  from enrolement where name= '" + studName + " and level='" + level + "' and subject= '" + subject3 + "'", con);
                count = Convert.ToInt32(cmd8.ExecuteScalar().ToString());
                if (count > 0)
                {
                    status = "Already enrolled in class";
                    con.Close();
                    return status;
                }
                con.Close();
                nm.Clear();
                con.Open();
                SqlCommand cmd4 = new SqlCommand("select tutor, charge from subject where level='" + level + "' and subject= '" + subject3 + "'", con);
                SqlDataReader r = cmd4.ExecuteReader();
                while (r.Read())
                {
                    nm.Add(r.GetString(0));//add element into arraylist
                    nm.Add(r.GetString(1));
                }
               
                tutor3 = (string)nm[0];
                charge3 = (string)nm[1];
                con.Close();
                con.Open();
                SqlCommand cmd3 = new SqlCommand("insert into enrolement (name, level, subject,tutor,payment,status) values (@name, @level,@sub,@tutor,@charge,'unpaid')", con);
                cmd3.Parameters.AddWithValue("@name", studName);
                cmd3.Parameters.AddWithValue("@level", level);
                cmd3.Parameters.AddWithValue("@sub", subject3);
                cmd3.Parameters.AddWithValue("@tutor", tutor3);
                cmd3.Parameters.AddWithValue("@charge", charge3);


                int k = cmd3.ExecuteNonQuery();
                if (i != 0)
                    status = "Subjects registered.";
                else
                    status = "unable to register.";
                con.Close();
            }
            else
            {
                return status;
            }

            return status;
            
        }

       

        public ArrayList viewCharge() //to link subjects from table and calculate 
        {
            ArrayList info= new ArrayList();
            
            
            
            con.Open();

            SqlCommand cmd = new SqlCommand("Select subject, payment from enrolement where name = @n and status='unpaid'", con);
            cmd.Parameters.AddWithValue("@n", studName);
            SqlDataReader r = cmd.ExecuteReader();
            while (r.Read())
            {
                info.Add(r.GetString(0)+"\t"+r.GetString(1));
                
            }
            con.Close();
            return info;

            
        }

        public ArrayList viewTotal()
        {
            ArrayList total = new ArrayList();
            
            con.Open();

            SqlCommand cmd = new SqlCommand("Select payment from enrolement where name = @n and status='unpaid'", con);
            cmd.Parameters.AddWithValue("@n", studName);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
              total.Add(rd.GetString(0));

            }
            con.Close();
            return total;


        }

        public string Payment(string m)
        {
            string status;
            string month = m;
            con.Open();
            SqlCommand cmd = new SqlCommand("update enrolement set status='paid' , month=@m where name = @n", con);
            cmd.Parameters.AddWithValue("@n", studName);
            cmd.Parameters.AddWithValue("@m", month);
            int i = cmd.ExecuteNonQuery();
            if (i != 0)
                status = "Payment Succesful";
            else
                status = "Payment unsuccesful";
            con.Close();
            return status;
        }

        public ArrayList viewStudent()
        {
            ArrayList nm = new ArrayList();
            con.Open();
            SqlCommand cmd = new SqlCommand("select name from students", con);
            SqlDataReader r = cmd.ExecuteReader();
            while (r.Read())
            {
                nm.Add(r.GetString(0));
            }
            con.Close();
            return nm;
        }

        public string deleteStudent()
        {
            string status;
            con.Open();
            SqlCommand test = new SqlCommand("select count (*) from students where name= '" + studName +"'", con);
            int count = Convert.ToInt32(test.ExecuteScalar().ToString());
            if (count == 0)
            {
                status = "Student not found";
                return status;
            }
            else
            {

                SqlCommand cmd = new SqlCommand("Delete from enrolement where name=@name", con);
                SqlCommand cmd1 = new SqlCommand("Delete from students where name = @name", con);
                SqlCommand cmd2 = new SqlCommand("Delete from users where username= @name", con);

                cmd.Parameters.AddWithValue("@name", studName);
                cmd1.Parameters.AddWithValue("@name", studName);
                cmd2.Parameters.AddWithValue("@name", studName);


                int i = cmd.ExecuteNonQuery();
                int j = cmd1.ExecuteNonQuery();
                if (i != 0)
                {
                    status = "Delete successfully.";
                }
                else
                {
                    status = "Unable to delete.";
                }
                con.Close();

                con.Open();
                if (j != 0)
                {
                    status = "Delete successfully.";
                }
                else
                {
                    status = "Unable to delete.";
                }
                con.Close();
                return status;
            }

        }

        public string viewReq( string n)
        {
            string request;
            con.Open();
            string name = n;
            SqlCommand cmd = new SqlCommand("select count (*) from requests where name=@n", con);
            cmd.Parameters.AddWithValue("@n", name);
            int count = Convert.ToInt32(cmd.ExecuteScalar().ToString());
            con.Close();
            if (count == 0)
            {
                request = "Student has no request";
                
                return request;
            }
            else
            {
                con.Open();
                SqlCommand cmd1 = new SqlCommand("select request from requests where name=@n", con);
                cmd1.Parameters.AddWithValue("@n", name);
                request = cmd1.ExecuteScalar().ToString();
                con.Close();
                return request;
            }



        }
                 
        public string approveReq(string n ) 
        {
            string status;
            string name=n;
            con.Open();
            SqlCommand cmd = new SqlCommand("Delete from requests where name=@n", con);
            cmd.Parameters.AddWithValue("@n", name);
            int i = cmd.ExecuteNonQuery();
            if (i != 0)
            {
                status = "Request accepted/deleted.";
            }
            else
            {
                status = "Unable to delete.";
            }
            con.Close();
            return status;

        }

        public int checkEnrol()
        {
            int count;
            int sub;
            
            con.Open();
            SqlCommand cmd = new SqlCommand("select count (*) from enrolement where name=@n", con);
            cmd.Parameters.AddWithValue("@n", studName);
            sub = Convert.ToInt32(cmd.ExecuteScalar().ToString());
            con.Close();
            if (sub==3)
            {
                count = -1;
            }
            else if (sub == 2)
            {
                count = 0;
            }
            else if (sub==1)
            {
                count = 1;
            }
            else if (sub == 0)
            {
                count = 2;
            }
            else
            {
                count = -1;
            }

            return count;
        }


    }



    

}
