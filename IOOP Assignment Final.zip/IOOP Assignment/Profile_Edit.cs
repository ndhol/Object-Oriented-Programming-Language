﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_Assignment
{
    public partial class frm_ProfileEdit : Form
    {
        public static string name;
        public frm_ProfileEdit()
        {
            InitializeComponent();
        }
        public frm_ProfileEdit(string n)
        {
            InitializeComponent();
            name = n;
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Student obj1= new Student(name);
            MessageBox.Show(obj1.updateProfile(txtBox_Email.Text, txtBox_ContactNum.Text, txtBox_Address.Text));
        }

        private void btn_Return_Click(object sender, EventArgs e)
        {
            frm_StudentPanel f2 = new frm_StudentPanel(name);
            f2.ShowDialog();
        }

        private void frm_ProfileEdit_Load(object sender, EventArgs e)
        {
            Student obj1 = new Student(name);
            //calling static method require className.method(..)
            //pass objectobj1 to method viewProfile
            Student.viewProfile(obj1);
            txtBox_Address.PlaceholderText = obj1.Address1;
            txtBox_ContactNum.PlaceholderText = obj1.PhoneNumber1;
            txtBox_Email.PlaceholderText = obj1.Email1;
            txtbox_Name.PlaceholderText = obj1.Name1;
            txtBox_Month.PlaceholderText = obj1.Month1; 
        }
    }
}
